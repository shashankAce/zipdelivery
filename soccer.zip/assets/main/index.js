System.register("chunks:///_virtual/AlignButton.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Widget, Component, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Widget = module.Widget;
      Component = module.Component;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "b7c79zdB3BBGLIpKo5JcGyy", "AlignButton", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var AlignButton = exports('AlignButton', (_dec = ccclass('AlignButton'), _dec2 = property({
        tooltip: "Top margin in pixels."
      }), _dec3 = property({
        tooltip: "Left or Right margin in pixels depending on alignment."
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(AlignButton, _Component);
        function AlignButton() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this.alignRight = false;
          _initializerDefineProperty(_this, "topMargin", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "sideMargin", _descriptor2, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = AlignButton.prototype;
        _proto.onLoad = function onLoad() {
          this.setAlignment(DataModel.data.lang == "ar");
          this.applyAlignment();
        };
        _proto.applyAlignment = function applyAlignment() {
          var widget = this.node.getComponent(Widget);
          if (!widget) {
            console.warn("Widget component not found on node:", this.node.name);
            return;
          }

          // Always align top
          widget.isAlignTop = true;
          widget.top = this.topMargin;

          // Clear bottom alignment
          widget.isAlignBottom = false;
          if (this.alignRight) {
            widget.isAlignRight = true;
            widget.right = this.sideMargin;
            widget.isAlignLeft = false;
          } else {
            widget.isAlignLeft = true;
            widget.left = this.sideMargin;
            widget.isAlignRight = false;
          }
          widget.updateAlignment();
        }

        // Optional: expose method to re-apply at runtime
        ;

        _proto.setAlignment = function setAlignment(alignRight, topMargin, sideMargin) {
          this.alignRight = alignRight;
          if (topMargin != null) this.topMargin = topMargin;
          if (sideMargin != null) this.sideMargin = sideMargin;
          this.applyAlignment();
        };
        return AlignButton;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "topMargin", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 64;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "sideMargin", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 24;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/AudioId.ts", ['cc'], function (exports) {
  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "c7da4MXwtdAkqKXEfm/vx2P", "AudioId", undefined);
      var AudioId = exports('AudioId', /*#__PURE__*/function (AudioId) {
        AudioId[AudioId["none"] = 0] = "none";
        AudioId[AudioId["football_crowd"] = 1] = "football_crowd";
        AudioId[AudioId["soccer_kick"] = 2] = "soccer_kick";
        AudioId[AudioId["metal_whistle"] = 3] = "metal_whistle";
        AudioId[AudioId["goal"] = 4] = "goal";
        AudioId[AudioId["miss"] = 5] = "miss";
        return AudioId;
      }({}));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BallController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './GameConfig.ts', './CustomEvent.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _createClass, cclegacy, _decorator, Node, CameraComponent, PhysicsSystem, game, input, Input, RigidBodyComponent, Vec3, log, Vec2, Component, Config, CustomGameEvent, EventName;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Node = module.Node;
      CameraComponent = module.CameraComponent;
      PhysicsSystem = module.PhysicsSystem;
      game = module.game;
      input = module.input;
      Input = module.Input;
      RigidBodyComponent = module.RigidBodyComponent;
      Vec3 = module.Vec3;
      log = module.log;
      Vec2 = module.Vec2;
      Component = module.Component;
    }, function (module) {
      Config = module.Config;
    }, function (module) {
      CustomGameEvent = module.CustomGameEvent;
      EventName = module.EventName;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _descriptor3;
      cclegacy._RF.push({}, "80960tUEQ5Jcrg2YCgNwwr1", "BallController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BALL_STATE = {
        NONE: "none",
        IDLE: "idle",
        DRAGGING: "dragging",
        KICKED: "kicked"
      };
      var BallController = exports('BallController', (_dec = ccclass('BallController'), _dec2 = property(Node), _dec3 = property(CameraComponent), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(BallController, _Component);
        function BallController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "ballNode", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "camera", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "groundY", _descriptor3, _assertThisInitialized(_this));
          _this._ballState = BALL_STATE.NONE;
          _this.isBallReset = false;
          _this.touchPoints = [];
          _this.touchTimes = [];
          _this.targetPos = null;
          _this.ballStartPosition = null;
          _this._touchReleased = true;
          _this.dragAllowed = false;
          return _this;
        }
        var _proto = BallController.prototype;
        _proto.onLoad = function onLoad() {
          var _this2 = this;
          this.setPhysicConfiguration();
          CustomGameEvent.on(EventName.ON_ANIM_FINISHED, this.onAnimationFinished, this);
          CustomGameEvent.on(EventName.ON_RESET_BALL, this.resetBall, this);
          this.ballState = BALL_STATE.NONE;
          this.scheduleOnce(function () {
            _this2.ballState = BALL_STATE.IDLE;
            _this2.isBallReset = true;
          }, 1);
        };
        _proto.setPhysicConfiguration = function setPhysicConfiguration() {
          // PhysicsSystem.instance.debugDrawFlags = EPhysicsDrawFlags.WIRE_FRAME
          //     | EPhysicsDrawFlags.AABB
          //     | EPhysicsDrawFlags.CONSTRAINT;
          var fps = 61;
          var timeStep = 1 / fps;
          PhysicsSystem.instance.fixedTimeStep = timeStep;
          game.frameRate = fps;
        };
        _proto.onAnimationFinished = function onAnimationFinished() {
          if (this.ballState != BALL_STATE.IDLE) this.ballState = BALL_STATE.IDLE;
        };
        _proto.onEnable = function onEnable() {
          input.on(Input.EventType.TOUCH_START, this.onTouchStart, this);
          input.on(Input.EventType.TOUCH_MOVE, this.onTouchMove, this);
          input.on(Input.EventType.TOUCH_END, this.onTouchEnd, this);
        };
        _proto.onDestroy = function onDestroy() {
          input.off(Input.EventType.TOUCH_START, this.onTouchStart, this);
          input.off(Input.EventType.TOUCH_MOVE, this.onTouchMove, this);
          input.off(Input.EventType.TOUCH_END, this.onTouchEnd, this);
        };
        _proto.onTouchStart = function onTouchStart(event) {
          if (this.ballState != BALL_STATE.IDLE) return;
          if (!this.touchReleased) return;
          if (!this.isBallReset) return;
          this.touchReleased = false;
          this.dragAllowed = true;

          //
          if (!this.ballStartPosition) this.ballStartPosition = this.ballNode.getWorldPosition();

          //
          var ballOrigPos = this.worldToScreen(this.ballStartPosition);
          var mag = event.getLocation().clone().subtract(ballOrigPos);
          if (mag.length() > Config.TOUCH_AREA) {
            // touch with in this area
            this.dragAllowed = false;
          } else {
            this.touchPoints = [event.getLocation()];
            this.touchTimes = [performance.now()];
          }
          var rb = this.ballNode.getComponent(RigidBodyComponent);
          if (rb) {
            rb.useGravity = false;
            rb.setLinearVelocity(Vec3.ZERO);
            rb.clearForces();
          }
        };
        _proto.onTouchMove = function onTouchMove(event) {
          if (!this.dragAllowed || this.touchReleased) return;
          if (this.ballState == BALL_STATE.KICKED) return;
          if (!this.isBallReset) return;
          var point = event.getLocation();
          this.touchPoints.push(point);
          this.touchTimes.push(performance.now());
          var mag = this.touchPoints[this.touchPoints.length - 1].clone().subtract(this.touchPoints[0]);
          if (mag.length() > 20) {
            this.ballState = BALL_STATE.DRAGGING;
          }
        };
        _proto.onTouchEnd = function onTouchEnd(event) {
          this.touchReleased = true;
          if (!this.isBallReset) return;
          if (this.ballState == BALL_STATE.DRAGGING) {
            var start = this.touchPoints[0];
            var current = this.touchPoints[this.touchPoints.length - 1];
            var dragY = current.y - start.y;
            if (dragY <= 0) {
              this.touchPoints = [];
              this.resetBall();
              this.ballState = BALL_STATE.IDLE;
              return;
            }
            this.releaseBall();
          } else if (this.ballState == BALL_STATE.IDLE) {
            this.touchPoints = [];
            this.resetBall();
          }
        };
        _proto.update = function update(dt) {
          if (this.touchPoints.length > 0 && this.dragAllowed) {
            var start = this.touchPoints[0].clone();
            var current = this.touchPoints[this.touchPoints.length - 1].clone();
            var dragY = current.y - start.y;
            //Prevent below drag
            if (dragY <= 0) {
              log('Drag Blocked', dragY);
              return;
            }
            var mag = current.clone().subtract(start);
            if (mag.length() > Config.MAX_DRAG) {
              this.releaseBall();
              return;
            }
            this.targetPos = this.screenToWorldOnPlane(current, this.groundY);

            // const dragPercent = Math.min(dragY / 200, 1); // clamp to 0-1 range
            // const height = dragPercent * 1;               // max Y offset (adjust)
            // const forward = dragPercent * 1;              // max Z offset (adjust)
            // const horizontal = Math.max(Math.min(dragX / 200, 1), -1);

            var currentPos = this.ballNode.getWorldPosition();
            var smoothed = Vec3.lerp(new Vec3(), currentPos, this.targetPos, 0.3);
            this.ballNode.setWorldPosition(smoothed);
          }
        };
        _proto.releaseBall = function releaseBall() {
          if (this.ballState != BALL_STATE.DRAGGING) return;
          if (!this.isBallReset) return;
          this.isBallReset = false;
          this.touchTimes.push(performance.now());
          var start = this.touchPoints[0].clone();
          var end = this.touchPoints[this.touchPoints.length - 1];

          // const dragY = end.y - start.y;
          // if (dragY <= 0) {
          //     console.log('Swipe ignored: ended below ball');
          //     this.targetPos = this.ballStartPosition;
          //     return;
          // }

          //X and Y velocity
          var swipeVector = end.clone().subtract(start);
          var estimatedTime = Math.min((this.touchTimes[this.touchTimes.length - 1] - this.touchTimes[0]) / 1000, 1);
          var yMag = Math.min(swipeVector.y / Config.MAX_DRAG, 1);
          var screenVelocity = swipeVector.clone().multiplyScalar(yMag).multiplyScalar(Config.VERTICAL_FORCE / 100).multiplyScalar(1.001 - estimatedTime);
          // const forwardForce = Math.min((1.01 - estimatedTime) * 100 * Config.FORWARD_FORCE / 100, Config.MAX_THROW_POWER);

          var distance = swipeVector.length();
          var forwardForce = Math.min(distance * 0.03 / estimatedTime, Config.MAX_THROW_POWER);
          log({
            forwardForce: forwardForce,
            yMag: yMag,
            screenVelocity: screenVelocity
          });

          // Swipe down check
          if (screenVelocity.y <= 0 || forwardForce == 0) {
            console.log('Swipe ignored: downward');
            this.touchPoints = [];
            this.touchTimes = [];
            this.resetBall();
            this.ballState = BALL_STATE.IDLE;
            return;
          } else {
            this.throwBall(screenVelocity, forwardForce);
            this.touchPoints = [];
            this.touchTimes = [];
          }
        };
        _proto.throwBall = function throwBall(screenVelocity, forwardForce) {
          var rb = this.ballNode.getComponent(RigidBodyComponent);
          if (!rb) return;
          this.ballState = BALL_STATE.KICKED;
          var impulse = new Vec3(screenVelocity.x,
          // * Config.VERTICAL_FORCE / 100,
          screenVelocity.y,
          // * Config.VERTICAL_FORCE / 100,
          -forwardForce);
          CustomGameEvent.dispatchEvent(EventName.ON_BALL_KICK, impulse);
          rb.useGravity = true;
          rb.clearForces();
          rb.setLinearVelocity(Vec3.ZERO);
          var dir = 1;
          if (screenVelocity.x < 0) {
            dir = -1;
          }
          rb.setAngularVelocity(new Vec3(-10, 5 * dir, 0));
          rb.applyImpulse(impulse);
        };
        _proto.resetBall = function resetBall() {
          this.isBallReset = true;
          var rb = this.ballNode.getComponent(RigidBodyComponent);
          rb.useGravity = false;
          rb.clearForces();
          rb.setLinearVelocity(Vec3.ZERO);
          rb.setAngularVelocity(Vec3.ZERO);
          if (this.ballStartPosition) this.ballNode.setWorldPosition(this.ballStartPosition);
        };
        _proto.worldToScreen = function worldToScreen(worldPos) {
          var _this$camera$worldToS, _this$camera;
          var screenPos = (_this$camera$worldToS = (_this$camera = this.camera) == null ? void 0 : _this$camera.worldToScreen(worldPos)) != null ? _this$camera$worldToS : new Vec3();
          return new Vec2(screenPos.x, screenPos.y);
        };
        _proto.screenToWorldOnPlane = function screenToWorldOnPlane(screenPos, y) {
          if (!this.camera) return null;
          var ray = this.camera.screenPointToRay(screenPos.x, screenPos.y);
          var t = (y - ray.o.y) / ray.d.y;
          return ray.o.add(ray.d.multiplyScalar(t));
        };
        _createClass(BallController, [{
          key: "ballState",
          get: function get() {
            return this._ballState;
          },
          set: function set(v) {
            this._ballState = v;
            log("ballState", v);
          }
        }, {
          key: "touchReleased",
          get: function get() {
            return this._touchReleased;
          },
          set: function set(v) {
            this._touchReleased = v;
            // log('TouchReleased', v)
          }
        }]);

        return BallController;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "ballNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "camera", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "groundY", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0.1;
        }
      })), _class2)) || _class));

      // calcImpulse() {
      //     if (!this.isDragging) return;

      //     this.isDragging = false;
      //     this.touchDisabled = true;
      //     this.touchReleased = false;

      //     this.touchTimes.push(performance.now());
      //     const start = this.touchPoints[0].clone();
      //     const end = this.touchPoints[this.touchPoints.length - 1];

      //     // Assume you have main camera reference
      //     const camera = this.camera;
      //     // Convert touch points to world points
      //     const startRay = camera.screenPointToRay(start.x, start.y);
      //     const endRay = camera.screenPointToRay(end.x, end.y);
      //     // Get a point along the rays (e.g., 10 units in front of camera)

      //     const startWorld = new Vec3();
      //     startRay.computeHit(startWorld, 10);

      //     const endWorld = new Vec3();
      //     endRay.computeHit(endWorld, 10);

      //     // Swipe direction in 3D world space
      //     const worldDirection = endWorld.subtract(startWorld).normalize();

      //     const swipeTime = (this.touchTimes[this.touchTimes.length - 1] - this.touchTimes[0]) / 1000;
      //     const swipeDistance = end.subtract(start).length();
      //     const velocityMagnitude = swipeDistance / (swipeTime || 1e-6); // pixels per second

      //     const scaleFactor = .1;
      //     const impulseStrength = velocityMagnitude * scaleFactor; // tune scaleFactor
      //     const impulse = worldDirection.multiplyScalar(impulseStrength);

      //     const rb = this.ballNode.getComponent(RigidBodyComponent);

      //     rb.useGravity = true;
      //     rb.clearForces();
      //     rb.setLinearVelocity(Vec3.ZERO);
      //     rb.applyImpulse(impulse);

      //     this.touchPoints = [];
      //     this.touchTimes = [];
      // }
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/CheatController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './GameConfig.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Node, Label, Vec3, UITransform, tween, Component, Config;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Node = module.Node;
      Label = module.Label;
      Vec3 = module.Vec3;
      UITransform = module.UITransform;
      tween = module.tween;
      Component = module.Component;
    }, function (module) {
      Config = module.Config;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3;
      cclegacy._RF.push({}, "56a923DeV1BVqwOKGL/jvB2", "CheatController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var CheatController = exports('CheatController', (_dec = ccclass('CheatController'), _dec2 = property(Node), _dec3 = property(Label), _dec4 = property(Label), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(CheatController, _Component);
        function CheatController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "cheatLayout", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "timerMsg", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "lifeMsg", _descriptor3, _assertThisInitialized(_this));
          _this.isShowing = false;
          _this.isTweening = false;
          return _this;
        }
        var _proto = CheatController.prototype;
        _proto.onLoad = function onLoad() {
          {
            this.node.active = Config.IS_DEBUG;
            this.isShowing = false;
            var pos = this.cheatLayout.getPosition();
            this.cheatLayout.setPosition(new Vec3(pos.x, this.cheatLayout.getComponent(UITransform).height + 20, pos.z));
            this.timerMsg.string = Config.PAUSE_TIMER ? "Resume Timer" : "Pause Timer";
            this.lifeMsg.string = Config.PAUSE_LIFE_DEC ? "Resume Life Dec" : "Pause Life Dec";
          }
        };
        _proto.onCheatClick = function onCheatClick() {
          {
            if (this.isTweening) return;
            if (this.isShowing) {
              this.hide();
            } else {
              this.show();
            }
          }
        };
        _proto.show = function show() {
          var _this2 = this;
          {
            this.isShowing = true;
            this.isTweening = true;
            var pos = this.cheatLayout.getPosition();
            tween(this.cheatLayout).to(.2, {
              position: new Vec3(pos.x, 0, pos.z)
            }, {
              easing: "sineIn"
            }).call(function () {
              _this2.isTweening = false;
            }).start();
          }
        };
        _proto.hide = function hide() {
          var _this3 = this;
          {
            this.isShowing = false;
            this.isTweening = true;
            var pos = this.cheatLayout.getPosition();
            tween(this.cheatLayout).to(.2, {
              position: new Vec3(pos.x, this.cheatLayout.getComponent(UITransform).height + 20, pos.z)
            }, {
              easing: "sineOut"
            }).call(function () {
              _this3.isTweening = false;
            }).start();
          }
        };
        _proto.onPauseTimer = function onPauseTimer() {
          {
            Config.PAUSE_TIMER = !Config.PAUSE_TIMER;
            this.timerMsg.string = Config.PAUSE_TIMER ? "Resume Timer" : "Pause Timer";
          }
        };
        _proto.onPauseLife = function onPauseLife() {
          {
            Config.PAUSE_LIFE_DEC = !Config.PAUSE_LIFE_DEC;
            this.lifeMsg.string = Config.PAUSE_LIFE_DEC ? "Resume Life Dec" : "Pause Life Dec";
          }
        };
        return CheatController;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cheatLayout", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "timerMsg", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "lifeMsg", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/CustomEvent.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _inheritsLoose, cclegacy;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "6efeaPFPeNFPIKB07odXJ/F", "CustomEvent", undefined);
      var OneToMultiListener = /*#__PURE__*/function () {
        function OneToMultiListener() {}
        OneToMultiListener.on = function on(eventName, handler, target) {
          var objHandler = {
            handler: handler,
            target: target
          };
          var handlerList = this.handlers[eventName];
          if (!handlerList) {
            handlerList = [];
            this.handlers[eventName] = handlerList;
          }
          for (var i = 0; i < handlerList.length; i++) {
            if (!handlerList[i]) {
              handlerList[i] = objHandler;
              return i;
            }
          }
          handlerList.push(objHandler);
          return handlerList.length;
        };
        OneToMultiListener.off = function off(eventName, handler, target) {
          var handlerList = this.handlers[eventName];
          if (!handlerList) {
            return;
          }
          for (var i = 0; i < handlerList.length; i++) {
            var oldObj = handlerList[i];
            if (oldObj.handler === handler && (!target || target === oldObj.target)) {
              handlerList.splice(i, 1);
              break;
            }
          }
        };
        OneToMultiListener.dispatchEvent = function dispatchEvent(eventName) {
          // if (this.supportEvent !== null && !this.supportEvent.hasOwnProperty(eventName)) {
          //     cc.error("please add the event into clientEvent.js");
          //     return;
          // }

          var handlerList = this.handlers[eventName];
          if (!handlerList) {
            return;
          }
          for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            args[_key - 1] = arguments[_key];
          }
          for (var i = 0; i < handlerList.length; i++) {
            var objHandler = handlerList[i];
            if (objHandler.handler) {
              try {
                objHandler.handler.apply(objHandler.target, args);
              } catch (error) {}
            }
          }
        };
        OneToMultiListener.setSupportEventList = function setSupportEventList(arrSupportEvent) {
          if (!(arrSupportEvent instanceof Array)) {
            console.log("supportEvent was not array");
            return false;
          }
          this.supportEvent = {};
          for (var i in arrSupportEvent) {
            var eventName = arrSupportEvent[i];
            this.supportEvent[eventName] = i;
          }
          return true;
        };
        return OneToMultiListener;
      }();
      OneToMultiListener.handlers = void 0;
      OneToMultiListener.supportEvent = void 0;
      var CustomGameEvent = exports('CustomGameEvent', /*#__PURE__*/function (_OneToMultiListener) {
        _inheritsLoose(CustomGameEvent, _OneToMultiListener);
        function CustomGameEvent() {
          return _OneToMultiListener.apply(this, arguments) || this;
        }
        return CustomGameEvent;
      }(OneToMultiListener));
      CustomGameEvent.handlers = {};
      var EventName = exports('EventName', {
        ON_PAUSED: "onPaused",
        ON_RESUME: "onResume",
        ON_ANIM_FINISHED: "onAnimFinished",
        ON_RESET_BALL: "onResetBall",
        ON_BALL_KICK: "onKickBall",
        UPDATE_TIME: "onTimeUpdate",
        UPDATE_LIFE: "onLifeUpdate"
      });
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/DataModel.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './env', './GameConfig.ts'], function (exports) {
  var _createClass, _extends, cclegacy, error, DEBUG, Config, supportedLanguage;
  return {
    setters: [function (module) {
      _createClass = module.createClass;
      _extends = module.extends;
    }, function (module) {
      cclegacy = module.cclegacy;
      error = module.error;
    }, function (module) {
      DEBUG = module.DEBUG;
    }, function (module) {
      Config = module.Config;
      supportedLanguage = module.supportedLanguage;
    }],
    execute: function () {
      cclegacy._RF.push({}, "3f26fpYovJOGbMPQZgqXhfM", "DataModel", undefined);
      var defaultGameData = {
        time: Config.DEFAULT_TIME,
        lang: Config.lang,
        lives: Config.DEFAULT_LIVES,
        isPractice: Config.DEFAULT_IS_PRACTICE,
        showTutorial: Config.DEFAULT_SHOW_TUTORIAL,
        bannerUrls: [],
        missedGoalDecisionTimeOut: Config.DEFAULT_MISSED_GOAL_DECISION_TIMEOUT,
        reactionRandomness: Config.REACTION_RANDOMNESS,
        difficultyProb: {
          easy: Config.DIFFICULTY_PROB.EASY,
          medium: Config.DIFFICULTY_PROB.MEDIUM,
          hard: Config.DIFFICULTY_PROB.HARD
        },
        goalLevel: Config.GOAL_LEVELS,
        animationSpeed: Config.ANIM_SPEED,
        ballResetTimer: Config.BALL_RESET_TIMER,
        skipAnimationTimer: Config.ANIMATION_SKIP_TIMER,
        hapticType: "impactLight",
        firstTimeToday: false
      };
      var DataModel = exports('DataModel', /*#__PURE__*/function () {
        function DataModel() {}
        DataModel.loadData = function loadData() {
          var _this = this;
          return new Promise(function (resolve, reject) {
            try {
              var _window;
              // Query
              // const params = new URLSearchParams(window.location.search || window.location.href);
              // const raw = params.get('gameData');
              // const gameData = JSON.parse(decodeURIComponent(raw || '{}'));

              // Window Refrence
              var gameData = ((_window = window) == null ? void 0 : _window.gameData) || {};
              console.log('GameData String', JSON.stringify(gameData));
              console.log('GameData Obj', gameData);
              var loaded = gameData;
              _this._data = _extends({}, defaultGameData, loaded, {
                difficultyProb: _extends({}, defaultGameData.difficultyProb, loaded.difficultyProb)
              });
              var language = _this._data.lang;
              language = language.split('-')[0];
              if (language) {
                if (supportedLanguage.indexOf(language) < 0) {
                  language = 'en';
                }
                _this._data.lang = language;
              }
              if (gameData.isPracticeMode) {
                _this._data.isPractice = gameData.isPracticeMode;
              }
              if (DEBUG) {
                var urlVals = _this.getUrlVars();
                if (urlVals["isDebug"]) {
                  Config.IS_DEBUG = urlVals["isDebug"] === 'true';
                }
                if (urlVals["lang"]) _this._data.lang = urlVals["lang"];
              }
              resolve();
            } catch (e) {
              error('Invalid gameData');
              reject();
            }
          });
        };
        DataModel.getUrlVars = function getUrlVars() {
          var vars = {};
          var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi,
          //@ts-ignore
          function (m, key, value) {
            vars[key] = value;
          });
          return vars;
        };
        _createClass(DataModel, null, [{
          key: "data",
          get: function get() {
            return this._data;
          },
          set: function set(v) {
            this._data = v;
          }
        }]);
        return DataModel;
      }());
      DataModel._data = null;
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Difficulty.ts", ['cc', './GameConfig.ts', './DataModel.ts'], function (exports) {
  var cclegacy, _decorator, Config, DataModel;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      Config = module.Config;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "8a76fRtfjBA2Yi8iBRCxIdb", "Difficulty", undefined);
      var ccclass = _decorator.ccclass;
      var GameDifficulty = exports('GameDifficulty', /*#__PURE__*/function (GameDifficulty) {
        GameDifficulty["EASY"] = "easy";
        GameDifficulty["MEDIUM"] = "medium";
        GameDifficulty["HARD"] = "hard";
        return GameDifficulty;
      }({}));
      var Difficulty = exports('Difficulty', (_dec = ccclass('Difficulty'), _dec(_class = /*#__PURE__*/function () {
        function Difficulty() {
          var _this$difficultyProbC;
          this.gameLevel = GameDifficulty.EASY;
          this.difficultyProbConfigs = (_this$difficultyProbC = {}, _this$difficultyProbC[GameDifficulty.EASY] = {
            probabilities: Config.DIFFICULTY_PROB.EASY
          }, _this$difficultyProbC[GameDifficulty.MEDIUM] = {
            probabilities: Config.DIFFICULTY_PROB.MEDIUM
          }, _this$difficultyProbC[GameDifficulty.HARD] = {
            probabilities: Config.DIFFICULTY_PROB.HARD
          }, _this$difficultyProbC);
          this.goalLevel = Config.GOAL_LEVELS;
          this.animSpeed = Config.ANIM_SPEED;
          this.difficultyProbConfigs.easy = {
            probabilities: DataModel.data.difficultyProb.easy
          };
          this.difficultyProbConfigs.medium = {
            probabilities: DataModel.data.difficultyProb.medium
          };
          this.difficultyProbConfigs.hard = {
            probabilities: DataModel.data.difficultyProb.hard
          };
          this.goalLevel = Config.GOAL_LEVELS;
          this.animSpeed = Config.ANIM_SPEED;
        }
        var _proto = Difficulty.prototype;
        _proto.setDifficulty = function setDifficulty(score) {
          if (score <= this.goalLevel[0]) this.gameLevel = GameDifficulty.EASY;else if (score <= this.goalLevel[1]) this.gameLevel = GameDifficulty.MEDIUM;else this.gameLevel = GameDifficulty.HARD;
        };
        _proto.getSpeed = function getSpeed() {
          var config = this.difficultyProbConfigs[this.gameLevel];
          return this.pickSpeedBasedOnProbability(this.animSpeed, config.probabilities);
        };
        _proto.pickSpeedBasedOnProbability = function pickSpeedBasedOnProbability(speeds, probabilities) {
          var rand = Math.random();
          var cumulative = 0;
          for (var i = 0; i < probabilities.length; i++) {
            cumulative += probabilities[i];
            if (rand < cumulative) {
              return speeds[i];
            }
          }
          // fallback
          return speeds[speeds.length - 1];
        };
        return Difficulty;
      }()) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Football.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, SphereCollider, RigidBody, Component;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      SphereCollider = module.SphereCollider;
      RigidBody = module.RigidBody;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "d0da48U2ORMoLJoyPnVL4OR", "Football", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var Football = exports('Football', (_dec = ccclass('Football'), _dec(_class = /*#__PURE__*/function (_Component) {
        _inheritsLoose(Football, _Component);
        function Football() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this.rigidBody = null;
          _this.collider = null;
          return _this;
        }
        var _proto = Football.prototype;
        _proto.onLoad = function onLoad() {
          this.collider = this.node.getComponent(SphereCollider);
          this.rigidBody = this.node.getComponent(RigidBody);
        };
        _proto.start = function start() {
          this.collider.on('onCollisionEnter', this.onBallCollition, this);
        };
        _proto.onBallCollition = function onBallCollition(event) {
          // console.log('Football Collided with ' + event.otherCollider.name);
          // if (event.otherCollider.name?.includes('mixamorig')) {
          //     this.kick(new Vec3(0, 0, 6));
          // }
        };
        _proto.kick = function kick(force, relativePoint) {
          // if (force && this.rigidBody) {
          //     this.rigidBody.applyImpulse(force, relativePoint);
          //     log("kicked from football");
          // }
        };
        return Football;
      }(Component)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameConfig.ts", ['cc'], function (exports) {
  var cclegacy, Vec3;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Vec3 = module.Vec3;
    }],
    execute: function () {
      cclegacy._RF.push({}, "c19f7pted5LVoUOEgqewAic", "GameConfig", undefined);
      var Config = exports('Config', function Config() {});
      Config.lang = 'en';
      Config.DEFAULT_TIME = 60;
      Config.BALL_DEFAULT_POST = new Vec3(0, 0.09, 7.0);
      Config.DEFAULT_LIVES = 3;
      Config.DEFAULT_SCORE = 0;
      Config.DEFAULT_SHOW_TUTORIAL = false;
      Config.DEFAULT_IS_PRACTICE = false;
      Config.DEFAULT_MISSED_GOAL_DECISION_TIMEOUT = 1.4;
      Config.DEFAULT_DIFFICULTY_INC_SCORE_COUNT = 10;
      // static readonly DEFAULT_PRECISION_REDUCTION_FACTOR: Record<TDifficulity, number> = {
      //     'easy': 5,
      //     'medium': 4,
      //     'hard': 0,
      // };
      Config.IS_DEBUG = false;
      Config.VERSION = "v1.51";
      Config.SKIP_COUNTDOWN = false;
      /// GAME BALL FORCE
      Config.TOUCH_AREA = 100;
      //px
      Config.MAX_DRAG = 100;
      //px
      Config.MAX_THROW_POWER = 40;
      //
      Config.FORWARD_FORCE = 50;
      Config.VERTICAL_FORCE = 10;
      // CHEAT
      Config.PAUSE_TIMER = false;
      Config.PAUSE_LIFE_DEC = false;
      Config.ANIMATION_Y_ARR = [11, 14];
      // Difficulty
      Config.REACTION_RANDOMNESS = 0.2;
      Config.GOAL_LEVELS = [10, 15];
      Config.ANIM_SPEED = [1, 1.35, 1.7];
      Config.BALL_RESET_TIMER = 700;
      Config.ANIMATION_SKIP_TIMER = 400;
      Config.DIFFICULTY_PROB = {
        EASY: [0.7, 0.2, 0.1],
        MEDIUM: [0.4, 0.3, 0.3],
        HARD: [0.1, 0.3, 0.6]
      };
      var supportedLanguage = exports('supportedLanguage', ["en", "ar"]);
      var supportedTextLanguage = exports('supportedTextLanguage', /*#__PURE__*/function (supportedTextLanguage) {
        supportedTextLanguage[supportedTextLanguage["default"] = 0] = "default";
        supportedTextLanguage[supportedTextLanguage["en"] = 1] = "en";
        supportedTextLanguage[supportedTextLanguage["ar"] = 2] = "ar";
        return supportedTextLanguage;
      }({}));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GameController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './Football.ts', './PlayerController.ts', './Score.ts', './Timer.ts', './Lives.ts', './MainCamera.ts', './SoundController.ts', './AudioId.ts', './QuitGamePopup.ts', './GameConfig.ts', './Difficulty.ts', './CustomEvent.ts', './GoalAnimation.ts', './PostMessageEvents.ts', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _createClass, cclegacy, _decorator, BoxCollider, Node, Label, Vec3, log, director, Component, Football, PlayerController, AnimationNames, Score, Timer, Lives, MainCamera, SoundController, AudioId, QuitGamePopup, Config, Difficulty, CustomGameEvent, EventName, GoalAnimation, PostMessageEvents, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      BoxCollider = module.BoxCollider;
      Node = module.Node;
      Label = module.Label;
      Vec3 = module.Vec3;
      log = module.log;
      director = module.director;
      Component = module.Component;
    }, function (module) {
      Football = module.Football;
    }, function (module) {
      PlayerController = module.PlayerController;
      AnimationNames = module.AnimationNames;
    }, function (module) {
      Score = module.Score;
    }, function (module) {
      Timer = module.Timer;
    }, function (module) {
      Lives = module.Lives;
    }, function (module) {
      MainCamera = module.MainCamera;
    }, function (module) {
      SoundController = module.SoundController;
    }, function (module) {
      AudioId = module.AudioId;
    }, function (module) {
      QuitGamePopup = module.QuitGamePopup;
    }, function (module) {
      Config = module.Config;
    }, function (module) {
      Difficulty = module.Difficulty;
    }, function (module) {
      CustomGameEvent = module.CustomGameEvent;
      EventName = module.EventName;
    }, function (module) {
      GoalAnimation = module.GoalAnimation;
    }, function (module) {
      PostMessageEvents = module.PostMessageEvents;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12;
      cclegacy._RF.push({}, "f4cd4zEas5MU6tHKmxBYq6h", "GameController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var GameController = exports('GameController', (_dec = ccclass('GameController'), _dec2 = property({
        type: MainCamera
      }), _dec3 = property({
        type: Football
      }), _dec4 = property({
        type: BoxCollider
      }), _dec5 = property({
        type: BoxCollider
      }), _dec6 = property({
        type: PlayerController
      }), _dec7 = property({
        type: Score
      }), _dec8 = property({
        type: Timer
      }), _dec9 = property({
        type: Lives
      }), _dec10 = property(QuitGamePopup), _dec11 = property(Node), _dec12 = property(Label), _dec13 = property(GoalAnimation), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(GameController, _Component);
        function GameController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "mainCamera", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "football", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "goalDetectionCollider", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "goalMissedDetectionCollider", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "player", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "scoreNode", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "timerNode", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "liveNode", _descriptor8, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "quitGamePopup", _descriptor9, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "practiceNode", _descriptor10, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "gameVersion", _descriptor11, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "goalAnimation", _descriptor12, _assertThisInitialized(_this));
          _this.score = Config.DEFAULT_SCORE;
          _this.totalKicks = 0;
          _this._lives = Config.DEFAULT_LIVES;
          _this.currentGoalStatus = 'WaitingForKick';
          // public missledGoalCheckTimer: number = null;
          // public successGoalResetTimer: number = null;
          _this.cameraStep = new Vec3(0, 0, -0.03);
          _this.diffculty = null;
          _this.ballResetTimer = Config.BALL_RESET_TIMER;
          // private gestureHandler: GestureRecogniser = new GestureRecogniser();
          _this.enablePractice = Config.DEFAULT_IS_PRACTICE;
          _this.deubgCount = 0;
          _this.gameStarted = false;
          return _this;
        }
        var _proto = GameController.prototype;
        _proto.start = function start() {
          this.lives = DataModel.data.lives;
          this.ballResetTimer = DataModel.data.ballResetTimer;
          this.enablePractice = DataModel.data.isPractice;
          this.gameVersion.string = "" + Config.VERSION;
          this.gameVersion.node.active = false;
          {
            this.gameVersion.string = "" + Config.VERSION;
            this.gameVersion.node.active = true;
          }
          this.practiceNode.active = this.enablePractice;
          this.diffculty = new Difficulty();
          CustomGameEvent.on(EventName.ON_BALL_KICK, this.onGestureRecognised, this);
          CustomGameEvent.on(EventName.ON_RESUME, this.closeGameListener, this);
        };
        _proto.startGame = function startGame() {
          this.gameStarted = true;
          SoundController.playMusic(AudioId.football_crowd, true, 1);

          // this.resetDifficulty();
          // this.gestureHandler.startRecognising(this.onGestureRecognised.bind(this));
          // this.goalDetectionCollider.on('onCollisionEnter', this.onGoalCollition, this);
          this.goalDetectionCollider.on('onTriggerEnter', this.onGoalCollition, this);
          this.goalMissedDetectionCollider.on('onCollisionEnter', this.onGoalMissedCollition, this);
          this.resetTimer();
          PostMessageEvents.sendEvent("rg_timer_start", {
            type: this.enablePractice ? 'practice' : 'play'
          });
        };
        _proto.onshowV = function onshowV() {
          if (this.deubgCount >= 20) {
            this.deubgCount = 0;
            this.showDebugV();
            this.unschedule(this.hideV);
            this.scheduleOnce(this.hideV, 1);
          } else this.deubgCount++;
        };
        _proto.hideV = function hideV() {
          this.gameVersion.node.active = false;
        };
        _proto.showDebugV = function showDebugV() {
          this.gameVersion.string = "" + this.getNewData(Config.VERSION, '');
          this.gameVersion.node.active = true;
        };
        _proto.onDisable = function onDisable() {
          // this.gestureHandler.stopRecognising();
          this.timerNode.stopTimer();
        };
        _proto.onDestroy = function onDestroy() {
          // this.gestureHandler.stopRecognising();
          this.timerNode.stopTimer();
        };
        _proto.onGoalCollition = function onGoalCollition(event) {
          console.log('Collided with ' + event.otherCollider.name);
          if (event.otherCollider.name === 'Football<SphereCollider>') {
            this.handleGoal();
            // if (this.successGoalResetTimer) {
            //     clearTimeout(this.successGoalResetTimer);
            //     this.successGoalResetTimer = null;
            // }
            // this.successGoalResetTimer = setTimeout(this.resetBall.bind(this), this.ballResetTimer);
            this.unschedule(this.resetBall);
            this.scheduleOnce(this.resetBall, this.ballResetTimer / 1000);
          }
        };
        _proto.onGoalMissedCollition = function onGoalMissedCollition(event) {
          console.log('Collided with ' + event.otherCollider.name);
          if (event.otherCollider.name === 'Football<SphereCollider>') {
            this.handleMissedGoal();
            // if (this.successGoalResetTimer) {
            //     clearTimeout(this.successGoalResetTimer);
            //     this.successGoalResetTimer = null;
            // }
            // this.successGoalResetTimer = setTimeout(this.resetBall.bind(this), this.ballResetTimer);
            this.unschedule(this.resetBall);
            this.scheduleOnce(this.resetBall, this.ballResetTimer / 1000);
          }
        };
        _proto.handleScoreUpdate = function handleScoreUpdate() {
          // this.scoreLabel.string = `<color=#00ff5a>Goals: </color><color=#0000ff>${this.score} / ${this.totalKicks}</color>`;
          if (this.scoreNode) this.scoreNode.setScore(this.score);
        };
        _proto.handleMissedGoal = function handleMissedGoal() {
          if (this.currentGoalStatus !== 'InProgress') return;
          console.log("Goal missed!!");
          SoundController.playEffect(AudioId.miss);
          this.currentGoalStatus = 'Miss';
          this.goalAnimation.onMissed();
          this.handleScoreUpdate();
          this.player.skipAnimation();
          if (!(Config.IS_DEBUG && Config.PAUSE_LIFE_DEC)) {
            this.lives--;
          }
          this.liveNode.setLives(this.lives);
          this.postGameUpdateMessage();
          if (this.lives <= 0) {
            this.finishGame();
          }
        };
        _proto.handleGoal = function handleGoal() {
          if (this.currentGoalStatus !== 'InProgress') return;
          console.log("Goal!!!!");
          SoundController.playEffect(AudioId.goal, false, 0.2);
          this.score++;
          console.log("Current Score " + this.score);
          this.currentGoalStatus = 'Goal';
          this.goalAnimation.onGoal();
          this.handleScoreUpdate();
          this.player.skipAnimation();
          PostMessageEvents.onHaptic();
          // 
          this.diffculty.setDifficulty(this.score);
        };
        _proto.resetBall = function resetBall() {
          var _this2 = this;
          console.log('current status in reset ball ' + this.currentGoalStatus);
          this.scheduleOnce(function () {
            _this2.mainCamera.resetCameraPosition();
          }, 0.25);
          // if (this.missledGoalCheckTimer) {
          //     clearTimeout(this.missledGoalCheckTimer);
          //     this.missledGoalCheckTimer = null;
          // }

          // if (this.successGoalResetTimer) {
          //     clearTimeout(this.successGoalResetTimer);
          //     this.successGoalResetTimer = null;
          // }
          this.unschedule(this.resetBall);

          // this.football.rigidBody.clearState();
          // this.football.rigidBody.setLinearVelocity(Vec3.ZERO);
          // this.football.rigidBody.setAngularVelocity(Vec3.ZERO);
          // this.football.node.setPosition(Config.BALL_DEFAULT_POST);

          CustomGameEvent.dispatchEvent(EventName.ON_RESET_BALL);
          if (this.currentGoalStatus !== 'GameOver') this.currentGoalStatus = 'WaitingForKick';
        };
        _proto.checkGoalAndResetBall = function checkGoalAndResetBall() {
          if (this.currentGoalStatus === 'InProgress') {
            this.handleMissedGoal();
            this.resetBall();
          }
        };
        _proto.onGestureRecognised = function onGestureRecognised(force) {
          if (this.currentGoalStatus !== 'WaitingForKick') return;
          this.kickFootball(force);
          this.mainCamera.followFootball(force);
          this.totalKicks++;
          var resetTimeout = DataModel.data.missedGoalDecisionTimeOut;
          this.goalKeeperAnimation(force);
          this.scheduleOnce(this.checkGoalAndResetBall.bind(this), resetTimeout);
        };
        _proto.getDelay = function getDelay(speed) {
          var maxDelay = 0.1;
          var minDelay = 0;
          var maxSpeed = Config.MAX_THROW_POWER;
          speed = Math.max(0, Math.min(speed, maxSpeed)); // Clamp to 0–40
          return maxDelay - speed / maxSpeed * (maxDelay - minDelay);
        };
        _proto.randomLeftRight = function randomLeftRight(force) {
          var randomness = DataModel.data.reactionRandomness;
          var isFlick = Math.random() > 1 - randomness;
          if (isFlick) {
            force.x = -force.x;
          }
          return force;
        };
        _proto.goalKeeperAnimation = function goalKeeperAnimation(force) {
          var duration = 0;
          var rotateFac = 0.2;
          var delay = 0; //this.getDelay(force.y);
          force = this.randomLeftRight(force.clone());
          var animSpeed = this.diffculty.getSpeed();
          log({
            animSpeed: animSpeed
          });
          if (force.y < Config.ANIMATION_Y_ARR[0]) {
            if (force.x >= 0) {
              if (force.x < 0.2) {
                this.player.playAnimation(AnimationNames.kick_stand_right, 1, delay, duration);
                this.player.setRotation(force.x * rotateFac);
              } else if (force.x < .5 && force.x >= 0.2) {
                this.player.playAnimation(AnimationNames.kick_stand_right, 1, delay, duration);
                this.player.setRotation(force.x * rotateFac);
              } else if (force.x < 1 && force.x >= 0.5) {
                this.player.playAnimation(AnimationNames.kick_stand_right, 1, delay, duration);
                this.player.setRotation(force.x * rotateFac);
              } else if (force.x < 2 && force.x >= 1) {
                this.player.playAnimation(AnimationNames.body_block_right, 1);
              } else if (force.x < 3 && force.x >= 2) {
                this.player.playAnimation(AnimationNames.body_block_right, 1);
              } else if (force.x < 4 && force.x >= 3) {
                this.player.playAnimation(AnimationNames.body_block_right, animSpeed);
              } else if (force.x >= 4) {
                this.player.playAnimation(AnimationNames.body_block_right, animSpeed);
              }
            } else {
              if (force.x >= -0.2) {
                this.player.playAnimation(AnimationNames.kick_stand_left, 1, delay, duration);
                this.player.setRotation(force.x * rotateFac);
              } else if (force.x > -0.5 && force.x <= -0.2) {
                this.player.playAnimation(AnimationNames.kick_stand_left, 1, delay, duration);
                this.player.setRotation(force.x * rotateFac);
              } else if (force.x > -1 && force.x <= -0.5) {
                this.player.playAnimation(AnimationNames.kick_stand_left, 1, delay, duration);
                this.player.setRotation(force.x * rotateFac);
              } else if (force.x > -2 && force.x <= -1) {
                this.player.playAnimation(AnimationNames.body_block_left, 1);
              } else if (force.x > -3 && force.x <= -2) {
                this.player.playAnimation(AnimationNames.body_block_left, 1);
              } else if (force.x > -4 && force.x <= -3) {
                this.player.playAnimation(AnimationNames.body_block_left, animSpeed);
              } else if (force.x <= -4) {
                this.player.playAnimation(AnimationNames.body_block_left, animSpeed);
              }
            }
          } else if (force.y < Config.ANIMATION_Y_ARR[1]) {
            var rotate = 0.1;
            if (force.x >= 0) {
              if (force.x <= 0.2) {
                this.player.playAnimation(AnimationNames.catch_scoop_right, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x < 1 && force.x > 0.2) {
                this.player.playAnimation(AnimationNames.catch_scoop_right, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x < 2 && force.x >= 1) {
                this.player.playAnimation(AnimationNames.catch_step_right, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x < 3 && force.x >= 2) {
                this.player.playAnimation(AnimationNames.catch_step_right, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x < 4 && force.x >= 3) {
                this.player.playAnimation(AnimationNames.dive_save_right, animSpeed, 0);
                // this.player.setRotation(force.x * rotate);
              } else if (force.x >= 4) {
                this.player.playAnimation(AnimationNames.dive_save_right, animSpeed, 0);
                // this.player.setRotation(force.x * rotate);
              }
            } else {
              if (force.x >= -0.2) {
                this.player.playAnimation(AnimationNames.catch_scoop_left, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x > -1 && force.x < -0.2) {
                this.player.playAnimation(AnimationNames.catch_scoop_left, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x > -2 && force.x <= -1) {
                this.player.playAnimation(AnimationNames.catch_step_left, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x > -3 && force.x <= -2) {
                this.player.playAnimation(AnimationNames.catch_step_left, animSpeed, 0);
                this.player.setRotation(force.x * rotate);
              } else if (force.x > -4 && force.x <= -3) {
                this.player.playAnimation(AnimationNames.dive_save_left, animSpeed, 0);
              } else if (force.x <= -4) {
                this.player.playAnimation(AnimationNames.dive_save_left, animSpeed, 0);
              }
            }
          } else if (force.y >= Config.ANIMATION_Y_ARR[0]) {
            var _rotate = 0.1;
            if (force.x >= 0) {
              if (force.x <= 0.2) {
                this.player.playAnimation(AnimationNames.header_soccerball, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x < 1 && force.x > 0.2) {
                this.player.playAnimation(AnimationNames.catch_jump_right, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x < 2 && force.x >= 1) {
                this.player.playAnimation(AnimationNames.catch_jump_right, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x < 3 && force.x >= 2) {
                this.player.playAnimation(AnimationNames.catch_jump_right, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x < 4 && force.x >= 3) {
                this.player.playAnimation(AnimationNames.dive_save_right, animSpeed, 0);
                // this.player.setRotation(diveRotate);
              } else if (force.x >= 4) {
                this.player.playAnimation(AnimationNames.dive_save_right, animSpeed, 0);
                // this.player.setRotation(diveRotate);
              }
            } else {
              if (force.x >= -0.2) {
                this.player.playAnimation(AnimationNames.header_soccerball, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x > -1 && force.x < -0.2) {
                this.player.playAnimation(AnimationNames.catch_jump_left, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x > -2 && force.x <= -1) {
                this.player.playAnimation(AnimationNames.catch_jump_left, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x > -3 && force.x <= -2) {
                this.player.playAnimation(AnimationNames.catch_jump_left, animSpeed, 0);
                this.player.setRotation(force.x * _rotate);
              } else if (force.x > -4 && force.x <= -3) {
                this.player.playAnimation(AnimationNames.dive_save_left, animSpeed, 0);
              } else if (force.x <= -4) {
                this.player.playAnimation(AnimationNames.dive_save_left, animSpeed, 0);
              }
            }
          }
        };
        _proto.kickFootball = function kickFootball(force) {
          if (this.football && this.currentGoalStatus === 'WaitingForKick') {
            SoundController.playEffect(AudioId.soccer_kick);
            this.currentGoalStatus = 'InProgress';
            var resetTimeout = DataModel.data.missedGoalDecisionTimeOut;
            this.scheduleOnce(this.checkGoalAndResetBall.bind(this), resetTimeout);
            // this.football.kick(force, new Vec3(0.01, 0.02, 0)); // kicking the ball on bottomish leftish 
            // this.football.kick(force, new Vec3(0, 0, 0)); // kicking the ball on bottomish leftish 
          }
        };

        _proto.resetTimer = function resetTimer() {
          var time = Config.DEFAULT_TIME;
          this.timerNode.startTimer(this.onTimeFinished.bind(this), time);
        };
        _proto.restartTheGame = function restartTheGame() {
          this.score = 0;
          this.totalKicks = 0;
          this.lives = 3;
          this.handleScoreUpdate();
          this.resetBall();
          this.resetTimer();
        };
        _proto.onTimeFinished = function onTimeFinished() {
          this.finishGame();
        };
        _proto.finishGame = function finishGame() {
          var _this3 = this;
          this.gameStarted = false;
          this.timerNode.stopTimer();
          this.currentGoalStatus = 'GameOver';
          var action = '';
          if (this.lives == 0) {
            action = 'life';
          } else if (this.timerNode.currentDisplayTime == 0) {
            action = 'timer';
          } else {
            action = 'quit';
          }
          PostMessageEvents.sendEvent('rg_game_end', {
            type: this.enablePractice ? 'practice' : 'play',
            action: action,
            score: this.score,
            time: this.timerNode.currentDisplayTime
          });
          this.scheduleOnce(function () {
            return _this3.goalAnimation.onGameOver().then(function () {});
          }, 0.5);
          this.scheduleOnce(function () {
            return _this3.postGameUpdateMessage();
          }, 2);
        };
        _proto.postGameUpdateMessage = function postGameUpdateMessage() {
          PostMessageEvents.onGameUpdate({
            currentGoalStatus: this.currentGoalStatus,
            score: this.score,
            totalKicks: this.totalKicks,
            lives: this.lives,
            currentDisplayTime: this.timerNode.currentDisplayTime
          });
        };
        _proto.closeGameListener = function closeGameListener() {
          if (this.lives > 0 || this.timerNode.currentDisplayTime < 60) {
            if (this.gameStarted) {
              this.quitGamePopup.show(function () {
                director.pause();
                log('game paused');
              });
            }
          }
        };
        _proto.onResumeListener = function onResumeListener() {
          director.resume();
          PostMessageEvents.sendEvent('rg_cta', {
            pn: 'gameplay',
            action: "resume",
            type: this.enablePractice ? 'practice' : 'play'
          });
          this.quitGamePopup.hide();
          log('game resume');
        };
        _proto.onQuitListener = function onQuitListener() {
          director.resume();
          PostMessageEvents.sendEvent('rg_cta', {
            pn: 'gameplay',
            action: "exit",
            type: this.enablePractice ? 'practice' : 'play'
          });
          this.quitGamePopup.hide();
          this.finishGame();
          log('game quit');
        };
        _proto.getNewData = function getNewData(data, key) {
          var result = '';
          for (var i = 0; i < data.length; i++) {
            var charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
            result += String.fromCharCode(charCode);
          }
          return result;
        };
        _createClass(GameController, [{
          key: "lives",
          get: function get() {
            return this._lives;
          },
          set: function set(value) {
            this._lives = value;
            CustomGameEvent.dispatchEvent(EventName.UPDATE_LIFE, this._lives);
          }
        }]);
        return GameController;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "mainCamera", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "football", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "goalDetectionCollider", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "goalMissedDetectionCollider", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "player", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "scoreNode", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "timerNode", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "liveNode", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "quitGamePopup", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "practiceNode", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "gameVersion", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "goalAnimation", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GestureRecogniser.ts", ['cc'], function (exports) {
  var cclegacy, input, Input, sys, screen, math, Vec3, Vec2;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      input = module.input;
      Input = module.Input;
      sys = module.sys;
      screen = module.screen;
      math = module.math;
      Vec3 = module.Vec3;
      Vec2 = module.Vec2;
    }],
    execute: function () {
      cclegacy._RF.push({}, "1751ekohetNu6KNnAx70rTs", "GestureRecogniser", undefined);
      var GestureRecogniser = exports('GestureRecogniser', /*#__PURE__*/function () {
        function GestureRecogniser() {
          this.startingTime = void 0;
          this.startingPoint = new Vec2();
          this.endingPoint = new Vec2();
          this.onGestureRecognised = void 0;
        }
        var _proto = GestureRecogniser.prototype;
        _proto.startRecognising = function startRecognising(onGestureRecognised) {
          this.onGestureRecognised = onGestureRecognised;
          // Touch handlers for gesture recognition
          input.on(Input.EventType.TOUCH_START, this.onTouchEventStart, this);
          input.on(Input.EventType.TOUCH_MOVE, this.onTouchEventMove, this);
          input.on(Input.EventType.TOUCH_END, this.onTouchEventEnd, this);
          input.on(Input.EventType.TOUCH_CANCEL, this.onTouchEventCancel, this);
        };
        _proto.stopRecognising = function stopRecognising() {
          // Touch handlers for gesture recognition
          input.off(Input.EventType.TOUCH_START, this.onTouchEventStart, this);
          input.off(Input.EventType.TOUCH_MOVE, this.onTouchEventMove, this);
          input.off(Input.EventType.TOUCH_END, this.onTouchEventEnd, this);
          input.off(Input.EventType.TOUCH_CANCEL, this.onTouchEventCancel, this);
        };
        _proto.onTouchEventStart = function onTouchEventStart(event) {
          console.log('start touch id ' + event.touch.getID());
          event.getLocation(this.startingPoint);
          this.startingTime = sys.now();
        };
        _proto.onTouchEventMove = function onTouchEventMove(event) {
          event.getLocation(this.endingPoint);
        };
        _proto.onTouchEventEnd = function onTouchEventEnd(event) {
          event.getLocation(this.endingPoint);
          console.log('end touch id ' + event.touch.getID());

          // only recognise if the gesture is more than 10% of the screen height
          if (this.endingPoint.y - this.startingPoint.y > screen.resolution.height / 10) this.convertGestureToForce();
        };
        _proto.onTouchEventCancel = function onTouchEventCancel(event) {}

        /**
         * Converts the gesture to a force vector based on the starting and ending points of the gesture.
         * The force is calculated based on the difference in x and y coordinates, normalized by screen resolution.
         * The force is also adjusted by a quickness factor based on the time taken for the gesture.
         */;
        _proto.convertGestureToForce = function convertGestureToForce() {
          if (this.onGestureRecognised) {
            var randomXFactor = math.randomRange(-1 * GestureRecogniser.RANDOM_FACTOR_X_LIMIT, GestureRecogniser.RANDOM_FACTOR_X_LIMIT);
            var forceXFactor = (this.endingPoint.x - this.startingPoint.x + randomXFactor) / screen.resolution.width * 3;
            var timeInSeconds = (sys.now() - this.startingTime) / 1000;
            var quicknessFactor = timeInSeconds < 1.5 && timeInSeconds > 0 ? 0.35 / timeInSeconds : 1; // Prevent division by zero or too large values
            var randomYFactor = math.randomRange(-1 * GestureRecogniser.RANDOM_FACTOR_Y_LIMIT, GestureRecogniser.RANDOM_FACTOR_Y_LIMIT);
            var rawforceYFactor = (this.endingPoint.y - this.startingPoint.y + randomYFactor) / screen.resolution.height * 4.5 * quicknessFactor;
            var forceYFactor = rawforceYFactor < 5 ? rawforceYFactor : 5;
            var gestureForce = -4; //(Vec2.distance(this.startingPoint, this.endingPoint) / screen.resolution.width) / timeInSeconds * -3;
            console.log("Vec3(" + forceXFactor + ", " + forceYFactor + ", " + gestureForce + ") timeInSeconds: " + timeInSeconds + ", quicknessFactor: " + quicknessFactor);
            this.onGestureRecognised(new Vec3(forceXFactor, forceYFactor, gestureForce));
          }
        };
        return GestureRecogniser;
      }());
      GestureRecogniser.RANDOM_FACTOR_X_LIMIT = screen.resolution.width * 0.1;
      GestureRecogniser.RANDOM_FACTOR_Y_LIMIT = screen.resolution.height * 0.05;
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GoalAnimation.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Node, Vec3, tween, Component;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Node = module.Node;
      Vec3 = module.Vec3;
      tween = module.tween;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;
      cclegacy._RF.push({}, "42a93MBUOxJF5vTmgts15Qw", "GoalAnimation", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var GoalAnimation = exports('GoalAnimation', (_dec = ccclass('GoalAnimation'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(Node), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(GoalAnimation, _Component);
        function GoalAnimation() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "missed", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "goal", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "gameOver", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "gameOverOverlay", _descriptor4, _assertThisInitialized(_this));
          _this.isTweening = false;
          return _this;
        }
        var _proto = GoalAnimation.prototype;
        _proto.onLoad = function onLoad() {
          this.goal.setScale(new Vec3(0, 0, 0));
          this.missed.setScale(new Vec3(0, 0, 0));
          this.gameOver.setScale(new Vec3(0, 0, 0));
          this.gameOver.setPosition(new Vec3(0, -100, 0));
          this.gameOverOverlay.active = false;
        };
        _proto.onMissed = function onMissed() {
          return this.tweenNode(this.missed);
        };
        _proto.onGoal = function onGoal() {
          return this.tweenNode(this.goal);
        };
        _proto.onGameOver = function onGameOver() {
          var _this2 = this;
          return new Promise(function (resolve, reject) {
            _this2.gameOver.setScale(new Vec3(.1, .1, .1));
            _this2.gameOverOverlay.active = true;
            tween(_this2.gameOver).to(1, {
              scale: new Vec3(1, 1, 1),
              position: new Vec3(0, 0, 0)
            }).call(function () {
              _this2.isTweening = false;
              resolve();
            }).start();
          });
        };
        _proto.tweenNode = function tweenNode(node) {
          var _this3 = this;
          return new Promise(function (resolve, reject) {
            if (_this3.isTweening) {
              resolve();
              return;
            }
            node.setScale(new Vec3(.2, .2, .2));
            tween(node).to(0.2, {
              scale: new Vec3(1.1, 1.1, 1.1)
            }).to(0.1, {
              scale: new Vec3(1, 1, 1)
            }).delay(.6).call(function () {
              node.setScale(new Vec3(0, 0, 0));
              _this3.isTweening = false;
              resolve();
            }).start();
          });
        };
        return GoalAnimation;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "missed", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "goal", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "gameOver", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gameOverOverlay", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/GoalCheat.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BallController.ts', './PlayerController.ts', './GameConfig.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, EditBox, Layout, Prefab, Node, Vec3, SkeletalAnimation, instantiate, Label, Button, Vec2, Component, BallController, PlayerController, Config;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      EditBox = module.EditBox;
      Layout = module.Layout;
      Prefab = module.Prefab;
      Node = module.Node;
      Vec3 = module.Vec3;
      SkeletalAnimation = module.SkeletalAnimation;
      instantiate = module.instantiate;
      Label = module.Label;
      Button = module.Button;
      Vec2 = module.Vec2;
      Component = module.Component;
    }, function (module) {
      BallController = module.BallController;
    }, function (module) {
      PlayerController = module.PlayerController;
    }, function (module) {
      Config = module.Config;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11;
      cclegacy._RF.push({}, "ee6d2+P7xZAVrJ+ol9ESnrs", "GoalCheat", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var GoalCheat = exports('GoalCheat', (_dec = ccclass('GoalCheat'), _dec2 = property(PlayerController), _dec3 = property(BallController), _dec4 = property(EditBox), _dec5 = property(EditBox), _dec6 = property(EditBox), _dec7 = property(EditBox), _dec8 = property(EditBox), _dec9 = property(Layout), _dec10 = property(Prefab), _dec11 = property(Node), _dec12 = property(Node), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(GoalCheat, _Component);
        function GoalCheat() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this.animationType = null;
          _this.coordinates = Vec3.ZERO;
          _initializerDefineProperty(_this, "playerController", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "ballController", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "xCoord", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "yCoord", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "zCoord", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "speedBox", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "rotate", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "animLayout", _descriptor8, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bar", _descriptor9, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "container", _descriptor10, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "animButton", _descriptor11, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = GoalCheat.prototype;
        _proto.onLoad = function onLoad() {
          var _this2 = this;
          {
            this.container.active = false;
            this.animButton.active = Config.IS_DEBUG;
            this.animLayout.node.removeAllChildren();
            var animations = this.playerController.node.children[0].getComponent(SkeletalAnimation).clips;
            animations.forEach(function (value, index) {
              var bar = instantiate(_this2.bar);
              bar.children[0].getComponent(Label).string = value.name;
              var click = bar.getComponent(Button).clickEvents[0];
              click.target = _this2.node;
              click.component = "GoalCheat";
              click.handler = "onAnimationPick";
              click.customEventData = value.name;
              _this2.animLayout.node.addChild(bar);
            });
          }
        };
        _proto.onSubmit = function onSubmit() {
          {
            if (!this.animationType) this.animationType = "";
            this.coordinates = new Vec3(Number(this.xCoord.string), Number(this.yCoord.string), Number(this.zCoord.string));
            this.playerController._animName = this.animationType;
            if (this.speedBox.string != "") this.playerController._speed = Number(this.speedBox.string);
            if (this.rotate.string != "") this.playerController._rotate = Number(this.rotate.string);
            if (!this.ballController.ballStartPosition) this.ballController.ballStartPosition = this.ballController.ballNode.getWorldPosition();
            this.ballController.throwBall(new Vec2(this.coordinates.x, this.coordinates.y), this.coordinates.z);
          }
        };
        _proto.onAnimationPick = function onAnimationPick(event, data) {
          this.animationType = data;
        };
        _proto.toggle = function toggle() {
          {
            this.container.active = !this.container.active;
          }
        };
        return GoalCheat;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "playerController", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "ballController", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "xCoord", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "yCoord", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "zCoord", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "speedBox", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "rotate", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "animLayout", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "bar", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "animButton", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/InfiniteTextureScroll.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Material, Vec4, tween, Component;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Material = module.Material;
      Vec4 = module.Vec4;
      tween = module.tween;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "e8385MrktxFy4WOjLX5sej6", "InfiniteTextureScroll", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var InfiniteTextureScroll = exports('InfiniteTextureScroll', (_dec = ccclass('InfiniteTextureScroll'), _dec2 = property(Material), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(InfiniteTextureScroll, _Component);
        function InfiniteTextureScroll() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "targetMaterials", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "scrollSpeed", _descriptor2, _assertThisInitialized(_this));
          // Units per second
          _this._offset = new Vec4(0, 0, 0, 0);
          return _this;
        }
        var _proto = InfiniteTextureScroll.prototype;
        // Use Vec4 for tiling and offset
        _proto.start = function start() {
          var _this2 = this;
          if (this.targetMaterials.length == 0) return;

          // Initialize with zero offset
          this._offset.set(1, 1, -1, 0); // Default tiling (1, 1) and offset (0, 0)
          // this.targetMaterial.setProperty('tilingOffset', this._offset);
          this.targetMaterials.forEach(function (mat, index) {
            mat.setProperty('tilingOffset', _this2._offset);
          });

          // Create infinite tween
          tween(this._offset).repeatForever(tween().to(1 / this.scrollSpeed, {
            z: 1
          }, {
            onUpdate: function onUpdate() {
              // this.targetMaterial.setProperty('tilingOffset', this._offset);
              _this2.targetMaterials.forEach(function (mat, index) {
                mat.setProperty('tilingOffset', _this2._offset);
              });
            }
          }).call(function () {
            // Reset to 0 when reaching 1 to avoid precision issues
            _this2._offset.z = -1;
          })).start();
        };
        return InfiniteTextureScroll;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "targetMaterials", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scrollSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0.05;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LastSecMsg.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './CustomEvent.ts', './TextController.ts', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Label, tween, Vec3, Component, CustomGameEvent, EventName, TextController, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Label = module.Label;
      tween = module.tween;
      Vec3 = module.Vec3;
      Component = module.Component;
    }, function (module) {
      CustomGameEvent = module.CustomGameEvent;
      EventName = module.EventName;
    }, function (module) {
      TextController = module.default;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor;
      cclegacy._RF.push({}, "75ba7n5Zx9L16QdDJE3R9df", "LastSecMsg", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var LastSecMsg = exports('LastSecMsg', (_dec = ccclass('LastSecMsg'), _dec2 = property(Label), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(LastSecMsg, _Component);
        function LastSecMsg() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "lastSecLabel", _descriptor, _assertThisInitialized(_this));
          _this.isShown = false;
          _this.lifeCount = 0;
          _this.timeCount = 0;
          return _this;
        }
        var _proto = LastSecMsg.prototype;
        _proto.onEnable = function onEnable() {
          this.lifeCount = DataModel.data.lives;
          this.timeCount = DataModel.data.time;
          CustomGameEvent.on(EventName.UPDATE_TIME, this.onTimeUpdate, this);
          CustomGameEvent.on(EventName.UPDATE_LIFE, this.onLifeUpdate, this);
        };
        _proto.onDisable = function onDisable() {
          CustomGameEvent.off(EventName.UPDATE_TIME, this.onTimeUpdate, this);
          CustomGameEvent.off(EventName.UPDATE_LIFE, this.onLifeUpdate, this);
        };
        _proto.onTimeUpdate = function onTimeUpdate(time) {
          this.timeCount = time;
          this.showMsg();
        };
        _proto.onLifeUpdate = function onLifeUpdate(life) {
          this.lifeCount = life;
          this.showMsg();
        };
        _proto.showMsg = function showMsg() {
          if (this.lifeCount < 2 || this.timeCount < 10) {
            if (this.lifeCount < 2 && this.timeCount < 10) {
              //LIFE and TIME
              this.lastSecLabel.string = TextController.getRawText("LAST_SEC_3");
            } else if (this.timeCount < 10) {
              //TIME
              this.lastSecLabel.string = TextController.getRawText("LAST_SEC_1");
            } else {
              //LIFE
              this.lastSecLabel.string = TextController.getRawText("LAST_SEC_2");
            }
            this.alertLastSec();
          }
        };
        _proto.alertLastSec = function alertLastSec() {
          if (!this.isShown) {
            this.isShown = true;
            tween(this.node).to(.2, {
              position: new Vec3(0, 0, 0)
            }, {
              easing: 'sineInOut'
            }).start();
          }
        };
        return LastSecMsg;
      }(Component), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "lastSecLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Lives.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Sprite, tween, Vec3, Component;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Sprite = module.Sprite;
      tween = module.tween;
      Vec3 = module.Vec3;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3;
      cclegacy._RF.push({}, "04c7dwf3c9Mrr+aua8mW/in", "Lives", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var Lives = exports('Lives', (_dec = ccclass('Lives'), _dec2 = property({
        type: Sprite
      }), _dec3 = property({
        type: Sprite
      }), _dec4 = property({
        type: Sprite
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(Lives, _Component);
        function Lives() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "live1", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "live2", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "live3", _descriptor3, _assertThisInitialized(_this));
          _this.liveHighlightTween = null;
          _this.defaultLiveScale = 0;
          return _this;
        }
        var _proto = Lives.prototype;
        _proto.onLoad = function onLoad() {
          this.defaultLiveScale = this.live1.node.scale.x;
          // this.liveHighlight(this.live1.node);
        };

        _proto.start = function start() {};
        _proto.removeLife = function removeLife(liveSprite) {
          return new Promise(function (resolve, reject) {
            tween(liveSprite.node).to(0.5, {
              scale: new Vec3(1.5, 1.5, 1)
            }, {
              easing: 'sineIn'
            }).to(0.2, {
              scale: new Vec3(0, 0, 0)
            }, {
              easing: 'sineOut'
            }).union().call(function () {
              liveSprite.node.active = false;
              resolve();
            }).start();
          });
        };
        _proto.setLives = function setLives(lives) {
          var _this2 = this;
          if (lives < 0) lives = 0;
          switch (lives) {
            case 0:
              // this.liveHighlightTween.stop();
              this.liveHighlightTween.destroySelf();
              this.removeLife(this.live1);
              break;
            case 1:
              this.removeLife(this.live2).then(function () {
                _this2.liveHighlight(_this2.live1.node);
              });
              break;
            case 2:
              this.removeLife(this.live3);
              break;
          }
          // this.live1.node.active = lives > 0;
          // this.live2.node.active = lives > 1;
          // this.live3.node.active = lives > 2;
        };

        _proto.liveHighlight = function liveHighlight(node) {
          this.liveHighlightTween = tween(node).repeatForever(tween().to(.25, {
            scale: new Vec3(.7, .7, .7)
          }, {
            easing: "sineInOut"
          }).to(.25, {
            scale: new Vec3(this.defaultLiveScale, this.defaultLiveScale, this.defaultLiveScale)
          }, {
            easing: "sineInOut"
          })).start();
        };
        _proto.update = function update(deltaTime) {};
        return Lives;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "live1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "live2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "live3", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LoadingController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './TextController.ts', './StageLoadingFont.ts', './DataModel.ts', './PostMessageEvents.ts', './TextureToMaterial.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, ProgressBar, Node, Label, UITransform, Vec3, director, log, Component, TextController, StageLoadingFont, DataModel, PostMessageEvents, TextureToMaterial;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      ProgressBar = module.ProgressBar;
      Node = module.Node;
      Label = module.Label;
      UITransform = module.UITransform;
      Vec3 = module.Vec3;
      director = module.director;
      log = module.log;
      Component = module.Component;
    }, function (module) {
      TextController = module.default;
    }, function (module) {
      StageLoadingFont = module.default;
    }, function (module) {
      DataModel = module.DataModel;
    }, function (module) {
      PostMessageEvents = module.PostMessageEvents;
    }, function (module) {
      TextureToMaterial = module.TextureToMaterial;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5;
      cclegacy._RF.push({}, "06d1fmLkSRDx7CG2/5XbfUU", "LoadingController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var LoadingController = exports('LoadingController', (_dec = ccclass('LoadingController'), _dec2 = property(ProgressBar), _dec3 = property(Node), _dec4 = property(Label), _dec5 = property(TextController), _dec6 = property(TextureToMaterial), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(LoadingController, _Component);
        function LoadingController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "progressBar", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "barCog", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "progressLabel", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "textController", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bannerImages", _descriptor5, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = LoadingController.prototype;
        _proto.onLoad = /*#__PURE__*/function () {
          var _onLoad = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            var _this2 = this;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  console.log('GameLoaded');
                  this.hidePreSplash();
                  this.progressBar.progress = 0;
                  PostMessageEvents.onGameLoaded();
                  _context.next = 6;
                  return DataModel.loadData();
                case 6:
                  _context.prev = 6;
                  _context.next = 9;
                  return Promise.all([this.bannerImages.loadImagesFromUrls(DataModel.data.bannerUrls), this.loadLocalization().then(function () {
                    _this2.progressLabel.node.active = true;
                  }), this.preloadMainScene()]);
                case 9:
                  this.loadMainScene();
                  log('Data loaded:', DataModel.data);
                  _context.next = 16;
                  break;
                case 13:
                  _context.prev = 13;
                  _context.t0 = _context["catch"](6);
                  log('Error during loading:', _context.t0);
                case 16:
                case "end":
                  return _context.stop();
              }
            }, _callee, this, [[6, 13]]);
          }));
          function onLoad() {
            return _onLoad.apply(this, arguments);
          }
          return onLoad;
        }();
        _proto.hidePreSplash = function hidePreSplash() {
          var preSplash = document.getElementById("pre_splash");
          if (preSplash) preSplash.style.display = "none";
        };
        _proto.loadLocalization = /*#__PURE__*/function () {
          var _loadLocalization = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
            var lang;
            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  lang = DataModel.data.lang;
                  _context2.next = 3;
                  return StageLoadingFont.loadFont(lang);
                case 3:
                  _context2.next = 5;
                  return this.textController.loadTextResources(lang);
                case 5:
                case "end":
                  return _context2.stop();
              }
            }, _callee2, this);
          }));
          function loadLocalization() {
            return _loadLocalization.apply(this, arguments);
          }
          return loadLocalization;
        }();
        _proto.preloadMainScene = /*#__PURE__*/function () {
          var _preloadMainScene = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
            var _this3 = this;
            return _regeneratorRuntime().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  return _context3.abrupt("return", new Promise(function (resolve, reject) {
                    var uiTransform = _this3.progressBar.getComponent(UITransform);
                    var barWidth = (uiTransform == null ? void 0 : uiTransform.contentSize.width) || 0;
                    director.preloadScene('scene', function (completed, total) {
                      var progress = completed / total;
                      _this3.progressBar.progress = progress;
                      var posX = barWidth * (progress - 0.5);
                      _this3.barCog.setPosition(new Vec3(posX, 0, 0));
                    }, function (error) {
                      if (error) {
                        reject(error);
                      } else {
                        resolve();
                      }
                    });
                  }));
                case 1:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
          function preloadMainScene() {
            return _preloadMainScene.apply(this, arguments);
          }
          return preloadMainScene;
        }();
        _proto.loadMainScene = function loadMainScene() {
          var uiTransform = this.progressBar.getComponent(UITransform);
          var barWidth = (uiTransform == null ? void 0 : uiTransform.contentSize.width) || 0;
          this.progressBar.progress = 1;
          this.barCog.setPosition(new Vec3(barWidth * 0.5, 0, 0));
          director.loadScene('scene', function (error) {
            if (error) {
              log('Scene load error:', error);
            } else {
              log('Main scene loaded successfully');
            }
          });
        };
        return LoadingController;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "progressBar", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "barCog", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "progressLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "textController", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "bannerImages", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/LocaliseText.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './StageLoadingFont.ts', './TextController.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, CCString, Enum, Label, Component, FontCategory, StageLoadingFont, TextController;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      CCString = module.CCString;
      Enum = module.Enum;
      Label = module.Label;
      Component = module.Component;
    }, function (module) {
      FontCategory = module.FontCategory;
      StageLoadingFont = module.default;
    }, function (module) {
      TextController = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5;
      cclegacy._RF.push({}, "5d49cGbr9tBPIf0iRuSOT/4", "LocaliseText", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var LocaliseText = exports('LocaliseText', (_dec = ccclass('LocaliseText'), _dec2 = property(CCString), _dec3 = property({
        type: Enum(FontCategory),
        visible: function visible() {
          return !this.systemFont;
        }
      }), _dec4 = property({
        visible: function visible() {
          return this.systemFont;
        }
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(LocaliseText, _Component);
        function LocaliseText() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "key", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "isBold", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "systemFont", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "fontCategory", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "fontFamily", _descriptor5, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = LocaliseText.prototype;
        _proto.onEnable = function onEnable() {
          var label = this.node.getComponent(Label);
          var text_id = this.key ? this.key : label.string;
          label.string = TextController.getRawText(text_id);
          if (this.systemFont) label.fontFamily = this.fontFamily;else {
            label.font = StageLoadingFont.getFont(this.fontCategory);
          }
          // label.isBold = this.isBold;
        };

        return LocaliseText;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "key", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return "";
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "isBold", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "systemFont", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "fontCategory", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return FontCategory.MAIN;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "fontFamily", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return "Arial";
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/main", ['./AudioId.ts', './SoundController.ts', './BallController.ts', './CheatController.ts', './Difficulty.ts', './Football.ts', './GameConfig.ts', './GameController.ts', './GoalAnimation.ts', './LastSecMsg.ts', './Lives.ts', './LoadingController.ts', './ProgressBarController.ts', './MainCamera.ts', './PlayerController.ts', './QuitGamePopup.ts', './Score.ts', './Timer.ts', './TutorialController.ts', './AlignButton.ts', './CustomEvent.ts', './DataModel.ts', './GestureRecogniser.ts', './GoalCheat.ts', './InfiniteTextureScroll.ts', './LocaliseText.ts', './PauseGameInterrupt.ts', './PostMessageEvents.ts', './StageLoadingFont.ts', './TextController.ts', './TextureToMaterial.ts', './UtilsStageLoading.ts'], function () {
  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

System.register("chunks:///_virtual/MainCamera.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, tween, Vec3, Quat, Component;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      tween = module.tween;
      Vec3 = module.Vec3;
      Quat = module.Quat;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "c7535j3gO5LioIQNsdGcT41", "MainCamera", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var MainCamera = exports('MainCamera', (_dec = ccclass('MainCamera'), _dec(_class = /*#__PURE__*/function (_Component) {
        _inheritsLoose(MainCamera, _Component);
        function MainCamera() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this.cameraDefaultPosition = new Vec3(0, 0, 0);
          _this.cameraDefaultRotation = new Quat(0, 0, 0, 1);
          return _this;
        }
        var _proto = MainCamera.prototype;
        _proto.start = function start() {
          this.node.getPosition(this.cameraDefaultPosition);
          this.node.getRotation(this.cameraDefaultRotation);
        };
        _proto.resetCameraPosition = function resetCameraPosition() {
          tween(this.node).to(1, {
            position: this.cameraDefaultPosition,
            rotation: this.cameraDefaultRotation
          }, {
            easing: 'circOut'
          })
          // .by(1, {scale: new Vec3(-1, -1, -1)}, {easing: 'sineOutIn'})
          .start();
        };
        _proto.followFootball = function followFootball(footballForce) {
          // tween(this.node)
          //     .to(1, {
          //         position: new Vec3(
          //             0,
          //             0.5,
          //             5,
          //         ),
          //         rotation: new Quat(
          //             this.cameraDefaultRotation.x + 0.025,
          //             footballForce.x * -0.2,
          //             this.cameraDefaultRotation.z,
          //             this.cameraDefaultRotation.w
          //         )
          //         },
          //         { easing: 'sineIn'}
          // )
          //     // .by(1, {scale: new Vec3(-1, -1, -1)}, {easing: 'sineOutIn'})
          //     .start()
        };
        _proto.update = function update(deltaTime) {};
        return MainCamera;
      }(Component)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PauseGameInterrupt.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './CustomEvent.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, game, Game, log, Component, CustomGameEvent, EventName;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      game = module.game;
      Game = module.Game;
      log = module.log;
      Component = module.Component;
    }, function (module) {
      CustomGameEvent = module.CustomGameEvent;
      EventName = module.EventName;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "05efafqEr9DT5Ji/zvZwPc4", "PauseGameInterrupt", undefined);
      var ccclass = _decorator.ccclass;
      var PauseGameInterrupt = exports('PauseGameInterrupt', (_dec = ccclass('PauseGameInterrupt'), _dec(_class = /*#__PURE__*/function (_Component) {
        _inheritsLoose(PauseGameInterrupt, _Component);
        function PauseGameInterrupt() {
          return _Component.apply(this, arguments) || this;
        }
        var _proto = PauseGameInterrupt.prototype;
        _proto.onLoad = function onLoad() {
          game.on(Game.EVENT_HIDE, this.onAppPaused, this);
          game.on(Game.EVENT_SHOW, this.onAppResumed, this);
        };
        _proto.onDestroy = function onDestroy() {
          game.off(Game.EVENT_HIDE, this.onAppPaused, this);
          game.off(Game.EVENT_SHOW, this.onAppResumed, this);
        };
        _proto.onAppPaused = function onAppPaused() {
          game.pause();
          log('game paused');
        };
        _proto.onAppResumed = function onAppResumed() {
          game.resume();
          CustomGameEvent.dispatchEvent(EventName.ON_RESUME);
          // log('game resume');
        };

        return PauseGameInterrupt;
      }(Component)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PlayerController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './CustomEvent.ts', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, SkeletalAnimation, Quat, error, log, Component, CustomGameEvent, EventName, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      SkeletalAnimation = module.SkeletalAnimation;
      Quat = module.Quat;
      error = module.error;
      log = module.log;
      Component = module.Component;
    }, function (module) {
      CustomGameEvent = module.CustomGameEvent;
      EventName = module.EventName;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor;
      cclegacy._RF.push({}, "d6e03OsAKpLw60OHCwUv9ka", "PlayerController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var AnimationNames = exports('AnimationNames', /*#__PURE__*/function (AnimationNames) {
        AnimationNames["body_block_left"] = "goalkeeper body block left";
        AnimationNames["body_block_right"] = "goalkeeper body block right";
        AnimationNames["catch_jump_left"] = "goalkeeper catch jump left";
        AnimationNames["catch_jump_right"] = "goalkeeper catch jump right";
        AnimationNames["catch_scoop_left"] = "goalkeeper catch scoop left";
        AnimationNames["catch_scoop_right"] = "goalkeeper catch scoop right";
        AnimationNames["catch_step_left"] = "goalkeeper catch step left";
        AnimationNames["catch_step_right"] = "goalkeeper catch step right";
        AnimationNames["dive_save_left"] = "goalkeeper diving save left";
        AnimationNames["dive_save_right"] = "goalkeeper diving save right";
        AnimationNames["idle_looking_down"] = "goalkeeper idle looking down";
        AnimationNames["header_soccerball"] = "header soccerball";
        AnimationNames["kick_stand_right"] = "pass right";
        AnimationNames["kick_stand_left"] = "pass left";
        AnimationNames["taunt_gesture"] = "Taunt Gesture";
        return AnimationNames;
      }({}));
      var PlayerController = exports('PlayerController', (_dec = ccclass('PlayerController'), _dec2 = property({
        type: SkeletalAnimation
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(PlayerController, _Component);
        function PlayerController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "animation", _descriptor, _assertThisInitialized(_this));
          _this._animName = null;
          _this._speed = null;
          _this._rotate = null;
          _this._currentAnimation = null;
          _this._skipTime = 0;
          return _this;
        }
        var _proto = PlayerController.prototype;
        _proto.start = function start() {
          this.animation.on(SkeletalAnimation.EventType.LASTFRAME, this.onJumpAnimationFinished, this);
          // this.animation.on(SkeletalAnimation.EventType.STOP, this.onJumpAnimationFinished, this);
        };

        _proto.onLoad = function onLoad() {
          this._skipTime = DataModel.data.skipAnimationTimer;
        };
        _proto.setRotation = function setRotation(value) {
          if (this._rotate) {
            value = this._rotate;
            this._rotate = null;
          }
          this.node.setRotation(new Quat(0, value, 0, 1));
        };
        _proto.playAnimation = function playAnimation(animationName, speed, delay, duration) {
          var _this2 = this;
          if (speed === void 0) {
            speed = 1;
          }
          if (delay === void 0) {
            delay = 0;
          }
          if (duration === void 0) {
            duration = null;
          }
          this._currentAnimation = animationName;
          this.scheduleOnce(function () {
            // Cheat
            {
              if (_this2._animName && _this2._animName != '') {
                animationName = _this2._animName;
                _this2._animName = null;
              }
              if (_this2._speed) {
                speed = _this2._speed;
                _this2._speed = null;
              }
            }
            // Cheat

            if (_this2.animation) {
              _this2.animation.crossFade(animationName, 0.1);
              // this.scheduleOnce(() => this.animation.crossFade(animationName, 0.1), 0);
            }

            if (duration) {
              _this2.stopAnimation(animationName, duration);
            }
            // if (animationName == AnimationNames.dive_save_right || animationName == AnimationNames.body_block_right)
            // speed += 0.2;

            var state = _this2.animation.getState(animationName);
            if (state) {
              state.speed = speed;
            } else {
              error(animationName, 'not found');
            }
          }, delay);
        };
        _proto.skipAnimation = function skipAnimation() {
          this.unschedule(this.skipAnim);
          this.scheduleOnce(this.skipAnim, this._skipTime / 1000);
        };
        _proto.skipAnim = function skipAnim() {
          if (this._currentAnimation != AnimationNames.idle_looking_down) {
            log('Skipping Animation');
            var state = this.animation.getState(this._currentAnimation);
            if (state) {
              state.speed = 2;
            }
          }
        };
        _proto.stopAnimation = function stopAnimation(animationName, afterDelay) {
          var _this3 = this;
          if (afterDelay === void 0) {
            afterDelay = 0;
          }
          if (this.animation) {
            this.scheduleOnce(function () {
              var state = _this3.animation.getState(animationName);
              if (state) {
                state.stop();
              }
            }, afterDelay);
          }
        };
        _proto.onJumpAnimationFinished = function onJumpAnimationFinished(type, state) {
          if (state.clip.name !== AnimationNames.idle_looking_down) {
            this._currentAnimation = AnimationNames.idle_looking_down;
            this.animation.crossFade(AnimationNames.idle_looking_down, 0.1);
            var _state = this.animation.getState(AnimationNames.idle_looking_down);
            _state.speed = 1;
            this.node.setRotation(new Quat(0, 0, 0, 1));
            this.scheduleOnce(function () {
              CustomGameEvent.dispatchEvent(EventName.ON_ANIM_FINISHED);
            }, 0.1);
          }
        };
        return PlayerController;
      }(Component), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "animation", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/PostMessageEvents.ts", ['cc', './DataModel.ts'], function (exports) {
  var cclegacy, _decorator, log, DataModel;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      log = module.log;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "2077blcvY5AHI/w865/kfj6", "PostMessageEvents", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var PostMessageEvents = exports('PostMessageEvents', (_dec = ccclass('PostMessageEvents'), _dec(_class = /*#__PURE__*/function () {
        function PostMessageEvents() {}
        PostMessageEvents.onGameLoaded = function onGameLoaded() {
          if (window && window.ReactNativeWebView) {
            log('PostMessage ', 'WEBVIEW_START_LOADING');
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: "WEBVIEW_START_LOADING",
              payload: {}
            }));
          } else {
            log('window reactnative ref not found');
          }
        };
        PostMessageEvents.sendEvent = function sendEvent(name, data) {
          if (data === void 0) {
            data = {};
          }
          if (window && window.ReactNativeWebView) {
            log('PostMessage ', "Type: NAT_EVENT, " + name + ", data " + JSON.stringify(data));
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: "NAT_EVENT",
              payload: {
                event_name: name,
                event_payload: data
              }
            }));
          } else {
            log('window reactnative ref not found');
          }
        };
        PostMessageEvents.onGameUpdate = function onGameUpdate(_ref) {
          var currentGoalStatus = _ref.currentGoalStatus,
            score = _ref.score,
            totalKicks = _ref.totalKicks,
            lives = _ref.lives,
            currentDisplayTime = _ref.currentDisplayTime;
          if (window && window.ReactNativeWebView) {
            log('PostMessage', "GameUpdate");
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: currentGoalStatus,
              score: score,
              totalKicks: totalKicks,
              lives: lives,
              time: currentDisplayTime
            }));
          } else {
            log('window reactnative ref not found');
          }
        };
        PostMessageEvents.onHaptic = function onHaptic() {
          if (window && window.ReactNativeWebView) {
            log('PostMessage ', "Type: HAPTIC_PRESS : " + DataModel.data.hapticType);
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: "HAPTIC_PRESS",
              payload: {
                feedback: DataModel.data.hapticType
              }
            }));
          } else {
            log('window reactnative ref not found');
          }
        };
        return PostMessageEvents;
      }()) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/ProgressBarController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, ProgressBar, Node, UITransform, math, Vec3, Component;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      ProgressBar = module.ProgressBar;
      Node = module.Node;
      UITransform = module.UITransform;
      math = module.math;
      Vec3 = module.Vec3;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "f91432zLSJPBpJ5oRy+3ycB", "ProgressBarController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var ProgressBarController = exports('ProgressBarController', (_dec = ccclass('ProgressBarController'), _dec2 = property(ProgressBar), _dec3 = property(Node), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(ProgressBarController, _Component);
        function ProgressBarController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "progressBar", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "barCog", _descriptor2, _assertThisInitialized(_this));
          _this.progressDuration = 0.1;
          _this.currentProgress = 0;
          // Current progress value
          _this.targetProgress = 0;
          // Target progress value
          _this.callback = null;
          _this.isEnabled = false;
          return _this;
        }
        var _proto = ProgressBarController.prototype;
        _proto.start = function start() {
          this.currentProgress = 0;
          this.targetProgress = 0;
          this.isEnabled = true;
        };
        _proto.update = function update(deltaTime) {
          if (!this.isEnabled) return;
          var uiTransform = this.progressBar.getComponent(UITransform);
          var width = (uiTransform == null ? void 0 : uiTransform.contentSize.width) || 0;

          // if (this.targetProgress >= 1) {
          //     this.progressDuration += 0.05;
          //     this.progressBar.progress = math.lerp(this.currentProgress, this.targetProgress, this.progressDuration);

          //     const posX = width * (this.progressBar.progress - 0.5);
          //     this.barCog.setPosition(new Vec3(posX, 0, 0));

          //     if (this.progressBar.progress >= 1) {
          //         this.isEnabled = false;
          //         this.callback && this.callback();
          //         this.callback = null;
          //     }
          // } else {
          this.currentProgress = math.lerp(this.currentProgress, this.targetProgress, this.progressDuration);
          this.progressBar.progress = this.currentProgress;
          var posX = width * (this.currentProgress - 0.5);
          this.barCog.setPosition(new Vec3(posX, 0, 0));
          // }
        };

        _proto.setProgress = function setProgress(newProgress) {
          if (newProgress < this.targetProgress) return;
          this.targetProgress = Math.min(1, Math.max(0, newProgress));
          this.isEnabled = true;
        };
        _proto.setFinalProgress = function setFinalProgress(newProgress) {
          var _this2 = this;
          return new Promise(function (resolve, reject) {
            _this2.callback = resolve;
            _this2.targetProgress = Math.min(1, Math.max(0, newProgress));
            _this2.progressDuration = 0.05;
            _this2.isEnabled = true;
          });
        };
        return ProgressBarController;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "progressBar", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "barCog", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/QuitGamePopup.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './PostMessageEvents.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, Vec3, UIOpacity, tween, Component, PostMessageEvents;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Vec3 = module.Vec3;
      UIOpacity = module.UIOpacity;
      tween = module.tween;
      Component = module.Component;
    }, function (module) {
      PostMessageEvents = module.PostMessageEvents;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "533a4N/XVNIEJG40lcbPc2J", "QuitGamePopup", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var QuitGamePopup = exports('QuitGamePopup', (_dec = ccclass('QuitGamePopup'), _dec(_class = /*#__PURE__*/function (_Component) {
        _inheritsLoose(QuitGamePopup, _Component);
        function QuitGamePopup() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this.isTweening = false;
          _this.isActive = false;
          _this.tweenTime = 0.15;
          return _this;
        }
        var _proto = QuitGamePopup.prototype;
        _proto.onLoad = function onLoad() {
          this.node.active = false;
        };
        _proto.show = function show(callback) {
          var _this2 = this;
          if (this.isActive) return;
          if (this.isTweening) return;
          this.isTweening = true;
          this.node.active = true;
          this.node.setScale(new Vec3(0.2, 0.2, 1));
          var uiOpacity = this.node.getComponent(UIOpacity);
          uiOpacity.opacity = 0;
          tween(this.node).to(this.tweenTime, {
            scale: new Vec3(1, 1, 1)
          }, {
            easing: "quadIn"
          }).start();
          tween(uiOpacity).to(this.tweenTime, {
            opacity: 255
          }, {
            easing: "quadIn"
          }).call(function () {
            _this2.isTweening = false;
            _this2.isActive = true;
            callback && callback();
          }).start();
          PostMessageEvents.sendEvent('rg_close');
        };
        _proto.hide = function hide(callback) {
          var _this3 = this;
          if (!this.isActive) return;
          if (this.isTweening) return;
          this.isTweening = true;
          this.node.active = true;
          this.node.setScale(new Vec3(1, 1, 1));
          var uiOpacity = this.node.getComponent(UIOpacity);
          uiOpacity.opacity = 255;
          tween(uiOpacity).to(this.tweenTime, {
            opacity: 0
          }, {
            easing: "quadIn"
          }).start();
          tween(this.node).to(this.tweenTime, {
            scale: new Vec3(0.2, 0.2, 1)
          }, {
            easing: "quadIn"
          }).call(function () {
            _this3.node.active = false;
            _this3.isTweening = false;
            _this3.isActive = false;
            callback && callback();
          }).start();
        };
        return QuitGamePopup;
      }(Component)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Score.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, LabelComponent, Component;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      LabelComponent = module.LabelComponent;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "b8e34cRupRI0KB8DbiZ5XNt", "Score", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var Score = exports('Score', (_dec = ccclass('Score'), _dec2 = property({
        type: LabelComponent
      }), _dec3 = property({
        type: LabelComponent
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(Score, _Component);
        function Score() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "scoreDigit1", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "scoreDigit2", _descriptor2, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = Score.prototype;
        _proto.start = function start() {};
        _proto.update = function update(deltaTime) {};
        _proto.setScore = function setScore(score) {
          if (score < 10) {
            this.scoreDigit1.string = '0';
            this.scoreDigit2.string = score.toString();
          } else {
            this.scoreDigit1.string = score.toString()[0];
            this.scoreDigit2.string = score.toString()[1];
          }
        };
        return Score;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "scoreDigit1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scoreDigit2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/SoundController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './AudioId.ts'], function (exports) {
  var _applyDecoratedDescriptor, _initializerDefineProperty, _inheritsLoose, _assertThisInitialized, cclegacy, _decorator, Enum, AudioClip, CCBoolean, AudioSource, director, error, Component, AudioId;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _initializerDefineProperty = module.initializerDefineProperty;
      _inheritsLoose = module.inheritsLoose;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Enum = module.Enum;
      AudioClip = module.AudioClip;
      CCBoolean = module.CCBoolean;
      AudioSource = module.AudioSource;
      director = module.director;
      error = module.error;
      Component = module.Component;
    }, function (module) {
      AudioId = module.AudioId;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _dec5, _dec6, _class4, _class5, _descriptor4, _class6;
      cclegacy._RF.push({}, "6d50fknUKZE5YSNJCpzkJOq", "SoundController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var AudioObject = exports('AudioObject', (_dec = ccclass('AudioObject'), _dec2 = property({
        type: Enum(AudioId)
      }), _dec3 = property({
        type: AudioClip
      }), _dec4 = property(CCBoolean), _dec(_class = (_class2 = function AudioObject() {
        _initializerDefineProperty(this, "name", _descriptor, this);
        _initializerDefineProperty(this, "audioClip", _descriptor2, this);
        _initializerDefineProperty(this, "isMusic", _descriptor3, this);
      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "name", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return AudioId.none;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "audioClip", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "isMusic", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      })), _class2)) || _class));
      var SoundController = exports('SoundController', (_dec5 = ccclass('SoundController'), _dec6 = property([AudioObject]), _dec5(_class4 = (_class5 = (_class6 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(SoundController, _Component);
        function SoundController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "arrayAudioObj", _descriptor4, _assertThisInitialized(_this));
          _this._audioSource = void 0;
          _this._effectAudioSource = void 0;
          _this._audioClipsMap = null;
          _this._musicVolume = 1;
          _this._effectVolume = 1;
          return _this;
        }
        var _proto = SoundController.prototype;
        _proto.onLoad = function onLoad() {
          SoundController.instance = this;
          this._audioSource = this.node.addComponent(AudioSource);
          this._effectAudioSource = this.node.addComponent(AudioSource);

          // Adding as persitance node to be used in main scene also
          director.addPersistRootNode(this.node);
        };
        SoundController.playMusic = function playMusic(id, loop, volume) {
          if (loop === void 0) {
            loop = true;
          }
          if (volume === void 0) {
            volume = 1;
          }
          this.instance._playMusic(id, loop, volume);
        };
        SoundController.playEffect = function playEffect(id, loop, volume) {
          if (loop === void 0) {
            loop = false;
          }
          if (volume === void 0) {
            volume = 1;
          }
          this.instance._playEffect(id, loop, volume);
        };
        SoundController.stopMusic = function stopMusic() {
          this.instance._audioSource.stop();
        };
        SoundController.stopEffect = function stopEffect() {
          this.instance._effectAudioSource.stop();
        };
        SoundController.setMusicVolume = function setMusicVolume(volume) {
          this.instance._musicVolume = volume;
          this.instance._audioSource.volume = volume;
        };
        SoundController.setEffectVolume = function setEffectVolume(volume) {
          this.instance._effectVolume = volume;
          this.instance._effectAudioSource.volume = volume;
        };
        _proto._playMusic = function _playMusic(id, loop, volume) {
          var audioObj = this.getAudioObject(id);
          if (!audioObj) {
            error("Audio clip not found: " + id);
            return;
          }
          this._audioSource.stop();
          this._audioSource.clip = audioObj.audioClip;
          this._audioSource.loop = loop;
          this._audioSource.volume = volume * this._musicVolume;
          this._audioSource.play();
        };
        _proto._playEffect = function _playEffect(id, loop, volume) {
          var audioObj = this.getAudioObject(id);
          if (!audioObj) {
            error("Audio clip not found: " + id);
            return;
          }

          // For effects, we play one-shot unless it's looped
          if (loop) {
            this._effectAudioSource.stop();
            this._effectAudioSource.clip = audioObj.audioClip;
            this._effectAudioSource.loop = loop;
            this._effectAudioSource.volume = volume * this._effectVolume;
            this._effectAudioSource.play();
          } else {
            this._effectAudioSource.playOneShot(audioObj.audioClip, volume * this._effectVolume);
          }
        };
        _proto.getAudioObject = function getAudioObject(name) {
          if (!this._audioClipsMap) {
            this.initMaps();
          }
          return this._audioClipsMap.get(name);
        };
        _proto.initMaps = function initMaps() {
          var _this2 = this;
          this._audioClipsMap = new Map();
          this.arrayAudioObj.forEach(function (obj, i) {
            _this2._audioClipsMap.set(obj.name, obj);
          });
        };
        return SoundController;
      }(Component), _class6.instance = void 0, _class6), _descriptor4 = _applyDecoratedDescriptor(_class5.prototype, "arrayAudioObj", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _class5)) || _class4));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/StageLoadingFont.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './GameConfig.ts', './UtilsStageLoading.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, Font, Component, supportedTextLanguage, UtilsStageLoading;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Font = module.Font;
      Component = module.Component;
    }, function (module) {
      supportedTextLanguage = module.supportedTextLanguage;
    }, function (module) {
      UtilsStageLoading = module.default;
    }],
    execute: function () {
      var _class, _class2, _MAIN, _REGULAR;
      cclegacy._RF.push({}, "e30480d4HZCubfxXUknlCQ/", "StageLoadingFont", undefined);
      var ccclass = _decorator.ccclass;
      var FontCategory = exports('FontCategory', /*#__PURE__*/function (FontCategory) {
        FontCategory[FontCategory["MAIN"] = 0] = "MAIN";
        FontCategory[FontCategory["REGULAR"] = 1] = "REGULAR";
        return FontCategory;
      }({})); // add categories as per requirement and path in reference section
      var StageLoadingFont = exports('default', ccclass(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(StageLoadingFont, _Component);
        function StageLoadingFont() {
          return _Component.apply(this, arguments) || this;
        }
        var _proto = StageLoadingFont.prototype;
        _proto.start = function start() {
          StageLoadingFont.instance = this;
        };
        StageLoadingFont.loadFont = function loadFont(language) {
          var _this = this;
          return new Promise(function (resolve, reject) {
            var categories = Object.keys(_this.references);
            var count = categories.length;
            categories.forEach(function (category, idx) {
              var config = _this.references[category][language];
              if (!config) {
                config = _this.references[category]["default"];
              }
              if (config.path == null) {
                count--;
                if (count == 0) resolve();
                return;
              }
              UtilsStageLoading.loadRes(config.path, Font, function (e, font) {
                // Ensure MAIN is 0, REGULAR is 1
                if (category === "MAIN") {
                  _this.font[0] = font;
                } else if (category === "REGULAR") {
                  _this.font[1] = font;
                }
                count--;
                if (count == 0) resolve();
              });
            });
          });
        };
        StageLoadingFont.getFont = function getFont(category) {
          if (category === void 0) {
            category = 0;
          }
          return this.font[category];
        }

        // update (dt) {}
        ;

        return StageLoadingFont;
      }(Component), _class2.font = [], _class2.instance = void 0, _class2.references = {
        //Default fonts for all languages
        MAIN: (_MAIN = {}, _MAIN[supportedTextLanguage[supportedTextLanguage["default"]]] = {
          path: "customFonts/en/Nippo-Variable",
          loading: false
        }, _MAIN[supportedTextLanguage[supportedTextLanguage.en]] = {
          path: "customFonts/en/Nippo-Variable",
          loading: false
        }, _MAIN[supportedTextLanguage[supportedTextLanguage.ar]] = {
          path: "customFonts/arabic/Cairo-Bold",
          loading: false
        }, _MAIN),
        REGULAR: (_REGULAR = {}, _REGULAR[supportedTextLanguage[supportedTextLanguage["default"]]] = {
          path: "customFonts/en/ProximaNova-Regular",
          loading: false
        }, _REGULAR[supportedTextLanguage[supportedTextLanguage.en]] = {
          path: "customFonts/en/ProximaNova-Regular",
          loading: false
        }, _REGULAR[supportedTextLanguage[supportedTextLanguage.ar]] = {
          path: "customFonts/arabic/Cairo-Regular",
          loading: false
        }, _REGULAR)
      }, _class2)) || _class);
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TextController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './GameConfig.ts', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _extends, cclegacy, _decorator, Sprite, Label, CCBoolean, CCString, resources, SpriteAtlas, log, Component, supportedLanguage, Config, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _extends = module.extends;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Sprite = module.Sprite;
      Label = module.Label;
      CCBoolean = module.CCBoolean;
      CCString = module.CCString;
      resources = module.resources;
      SpriteAtlas = module.SpriteAtlas;
      log = module.log;
      Component = module.Component;
    }, function (module) {
      supportedLanguage = module.supportedLanguage;
      Config = module.Config;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _class3;
      cclegacy._RF.push({}, "2ed7fHR3llAaomHTd8uR0M8", "TextController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var TextController = exports('default', (_dec = property([Sprite]), _dec2 = property([Label]), _dec3 = property(CCBoolean), _dec4 = property({
        type: [CCString],
        visible: function visible() {
          return this.isAutoReplaceMode;
        }
      }), ccclass(_class = (_class2 = (_class3 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(TextController, _Component);
        function TextController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "textSpriteList", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "rawTextList", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "isAutoReplaceMode", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "namePatternList", _descriptor4, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = TextController.prototype;
        // LIFE-CYCLE CALLBACKS:
        _proto.start = function start() {
          if (TextController.textInfo) {
            //resources are loaded
            this.replaceText();
            if (this.isAutoReplaceMode) {
              this.autoReplaceRawText();
            }
          }
          if (TextController.textAtlas) {
            this.replaceTextImage();
          }
        };
        TextController.getTextSpriteFrame = function getTextSpriteFrame(name) {
          return TextController.textAtlas.getSpriteFrame(name);
        };
        TextController.setText = function setText(sprite, name) {
          sprite.spriteFrame = TextController.textAtlas.getSpriteFrame(name);
        };
        TextController.getRawText = function getRawText(id) {
          return TextController.textInfo[id] ? TextController.textInfo[id] : id;
        };
        TextController.addTextInfo = function addTextInfo(obj, isOverwrite) {
          if (isOverwrite === void 0) {
            isOverwrite = true;
          }
          if (isOverwrite) {
            TextController.textInfo = _extends({}, TextController.textInfo, obj);
          } else {
            TextController.textInfo = _extends({}, obj, TextController.textInfo);
          }
        };
        _proto.loadTextResources = function loadTextResources(lang) {
          var _this2 = this;
          if (lang === void 0) {
            lang = null;
          }
          if (lang == null) lang = Config.lang;
          //image texts
          var img_loader = new Promise(function (resolve) {
            resources.load("locales/" + lang + "/text_atlas", SpriteAtlas, function (err, atlas) {
              if (err) {
                log("Error loading text atlas for lang " + lang);
                resolve();
                return;
              }
              if (lang != supportedLanguage[0]) {
                resources.release(supportedLanguage[0] + "/text_atlas");
              }
              TextController.textAtlas = atlas;
              _this2.replaceTextImage();
              resolve();
            });
          });

          //raw common texts
          var common_text_loader = new Promise(function (resolve) {
            resources.load("locales/" + lang + '/common', function (err, assets) {
              if (err) {
                log('Error loading common text for ' + lang);
                resolve();
                return;
              }
              if (assets) {
                TextController.addTextInfo(JSON.parse(assets.toString()), false);
              }
              resolve();
            });
          });

          //raw game specific texts
          var game_text_loader = new Promise(function (resolve) {
            resources.load("locales/" + lang + "/text", function (err, assets) {
              if (err) {
                log('Error loading game text for ' + lang);
                resolve();
                return;
              }
              if (lang != supportedLanguage[0]) {
                resources.release(supportedLanguage[0] + '/text');
              }
              TextController.addTextInfo(JSON.parse(assets.toString()));
              resolve();
            });
          });
          var custom_text_loader = new Promise(function (resolve) {
            if (lang == "th") {
              resources.load("locales/" + lang + "/font", function (err, fontAssets) {
                if (err) {
                  log("Error loading font for lang " + lang);
                  resolve();
                  return;
                }
                resolve();
              });
            } else {
              resolve();
            }
          });
          var text_loader = Promise.all([game_text_loader, custom_text_loader]).then(function () {
            return new Promise(function (resolve) {
              _this2.replaceRawText();
              resolve();
            });
          });
          return Promise.all([img_loader, text_loader]);
        };
        _proto.replaceTextImage = function replaceTextImage() {
          var sf;
          this.textSpriteList.forEach(function (sprite) {
            if (sprite && sprite.spriteFrame) {
              sf = TextController.textAtlas.getSpriteFrame(sprite.spriteFrame.name);
              if (sf) {
                sprite.spriteFrame = sf;
              }
            }
          });
        };
        _proto.replaceRawText = function replaceRawText() {
          var text_id;
          this.rawTextList.forEach(function (label) {
            if (label) {
              //Thai texts does not work well with Arial font
              if (DataModel.data.lang == "th") {
                label.cacheMode = Label.CacheMode.NONE;
              }
              text_id = label.string;
              if (TextController.textInfo[text_id]) {
                label.string = TextController.textInfo[text_id];
              }
            }
          });
        };
        _proto.replaceText = function replaceText() {
          // this.replaceTextImage();
          this.replaceRawText();
        };
        _proto.autoReplaceRawText = function autoReplaceRawText() {
          var _this3 = this;
          if (this.namePatternList.length <= 0) {
            return;
          }

          //iterate through all child nodes
          this.node.walk(undefined, function (child) {
            var is_matched = _this3.namePatternList.some(function (pattern) {
              return child.name.includes(pattern);
            });
            if (is_matched) {
              var label = child.getComponent(Label);
              if (label) {
                //Thai texts does not work well with Arial font
                if (DataModel.data.lang == "th") {
                  label.cacheMode = Label.CacheMode.NONE;
                }

                // const splittedString = (label.string.split("#")).filter((str) => str !== '');
                // if(splittedString.length > 1)
                // {
                //     let newString = "";
                //     splittedString.forEach(element => {
                //         newString += TextController.textInfo[element] as string;
                //     });
                //     if (newString) {
                //         label.string = newString;
                //     }
                // }

                var content_str = TextController.textInfo[label.string];
                if (content_str) {
                  label.string = content_str;
                }
              }
              // if (child.getComponent(MultiImageToText))
              //     child.getComponent(MultiImageToText).setkey("");
            }
          });
        };

        return TextController;
      }(Component), _class3.textAtlas = null, _class3.textInfo = null, _class3), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "textSpriteList", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "rawTextList", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "isAutoReplaceMode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "namePatternList", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TextureToMaterial.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, Material, Texture2D, assetManager, resources, Component, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Material = module.Material;
      Texture2D = module.Texture2D;
      assetManager = module.assetManager;
      resources = module.resources;
      Component = module.Component;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor;
      cclegacy._RF.push({}, "b049368YF5G7Ll/YI2mJK2/", "TextureToMaterial", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var TextureToMaterial = exports('TextureToMaterial', (_dec = ccclass('TextureToMaterial'), _dec2 = property(Material), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(TextureToMaterial, _Component);
        function TextureToMaterial() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "boundryMatArr", _descriptor, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = TextureToMaterial.prototype;
        _proto.loadImagesFromUrls = /*#__PURE__*/function () {
          var _loadImagesFromUrls = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(urls) {
            var _this2 = this;
            var getImageForIndex, promises;
            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  getImageForIndex = /*#__PURE__*/function () {
                    var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(url, index) {
                      var fallback, image;
                      return _regeneratorRuntime().wrap(function _callee$(_context) {
                        while (1) switch (_context.prev = _context.next) {
                          case 0:
                            fallback = function fallback() {
                              return _this2.loadLocalImage("locales/" + DataModel.data.lang + "/noon").then(function (image) {
                                return _this2.setTextureForIndex(index, image);
                              })["catch"](function (error) {
                                console.error("Failed to load local image for index " + index + ":", error);
                              });
                            };
                            if (!(!url || url.trim() === '')) {
                              _context.next = 3;
                              break;
                            }
                            return _context.abrupt("return", fallback());
                          case 3:
                            _context.prev = 3;
                            _context.next = 6;
                            return _this2.loadRemoteImage(url);
                          case 6:
                            image = _context.sent;
                            _this2.setTextureForIndex(index, image);
                            _context.next = 14;
                            break;
                          case 10:
                            _context.prev = 10;
                            _context.t0 = _context["catch"](3);
                            _context.next = 14;
                            return fallback();
                          case 14:
                          case "end":
                            return _context.stop();
                        }
                      }, _callee, null, [[3, 10]]);
                    }));
                    return function getImageForIndex(_x2, _x3) {
                      return _ref.apply(this, arguments);
                    };
                  }();
                  promises = [];
                  if (urls.length) {
                    this.boundryMatArr.forEach(function (mat, index) {
                      promises.push(getImageForIndex(urls[index], index));
                    });
                  } else {
                    this.boundryMatArr.forEach(function (_, index) {
                      promises.push(getImageForIndex('', index));
                    });
                  }
                  _context2.next = 5;
                  return Promise.all(promises);
                case 5:
                case "end":
                  return _context2.stop();
              }
            }, _callee2, this);
          }));
          function loadImagesFromUrls(_x) {
            return _loadImagesFromUrls.apply(this, arguments);
          }
          return loadImagesFromUrls;
        }();
        _proto.setTextureForIndex = function setTextureForIndex(index, image) {
          var _this$boundryMatArr$i;
          var texture = new Texture2D();
          texture.image = image;
          (_this$boundryMatArr$i = this.boundryMatArr[index]) == null || _this$boundryMatArr$i.setProperty('mainTexture', texture);
        };
        _proto.loadRemoteImage = function loadRemoteImage(url) {
          return new Promise(function (resolve, reject) {
            assetManager.loadRemote(url, function (err, imageAsset) {
              if (err) {
                reject(err);
                return;
              }
              resolve(imageAsset);
            });
          });
        };
        _proto.loadLocalImage = function loadLocalImage(url) {
          return new Promise(function (resolve, reject) {
            resources.load(url, function (err, imageAsset) {
              if (err) {
                reject(err);
                return;
              }
              resolve(imageAsset);
            });
          });
        };
        return TextureToMaterial;
      }(Component), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "boundryMatArr", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/Timer.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './GameConfig.ts', './CustomEvent.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, LabelComponent, Color, Component, Config, CustomGameEvent, EventName;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      LabelComponent = module.LabelComponent;
      Color = module.Color;
      Component = module.Component;
    }, function (module) {
      Config = module.Config;
    }, function (module) {
      CustomGameEvent = module.CustomGameEvent;
      EventName = module.EventName;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "0f725G9MzxIkocrayitIDQW", "Timer", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var TimerState = /*#__PURE__*/function (TimerState) {
        TimerState[TimerState["Running"] = 1] = "Running";
        TimerState[TimerState["Paused"] = 2] = "Paused";
        TimerState[TimerState["Stopped"] = 3] = "Stopped";
        return TimerState;
      }(TimerState || {});
      var Timer = exports('Timer', (_dec = ccclass('Timer'), _dec2 = property({
        type: LabelComponent
      }), _dec3 = property({
        type: LabelComponent
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(Timer, _Component);
        function Timer() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "timeDigit1", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "timeDigit2", _descriptor2, _assertThisInitialized(_this));
          _this.currentDisplayTime = 0;
          _this.timerState = TimerState.Stopped;
          _this.currentTime = 0;
          _this.allowedGameTime = 30;
          _this.onTimerFinished = null;
          return _this;
        }
        var _proto = Timer.prototype;
        _proto.start = function start() {
          // Optional: Initialize display here if needed
        };
        _proto.startTimer = function startTimer(onTimerFinished, allowedGameTime) {
          if (onTimerFinished === void 0) {
            onTimerFinished = null;
          }
          if (allowedGameTime === void 0) {
            allowedGameTime = 30;
          }
          this.allowedGameTime = allowedGameTime;
          this.currentTime = allowedGameTime;
          this.currentDisplayTime = Math.ceil(this.currentTime);
          this.updateTimeDisplay();
          this.timerState = TimerState.Running;
          this.onTimerFinished = onTimerFinished;
        };
        _proto.pauseTimer = function pauseTimer() {
          if (this.timerState === TimerState.Running) {
            this.timerState = TimerState.Paused;
          }
        };
        _proto.resumeTimer = function resumeTimer() {
          if (this.timerState === TimerState.Paused) {
            this.timerState = TimerState.Running;
          }
        };
        _proto.stopTimer = function stopTimer() {
          this.timerState = TimerState.Stopped;
        };
        _proto.update = function update(deltaTime) {
          {
            if (Config.IS_DEBUG && Config.PAUSE_TIMER) return;
          }
          if (this.timerState !== TimerState.Running) {
            return;
          }
          this.currentTime -= deltaTime;
          var newDisplayTime = Math.max(0, Math.ceil(this.currentTime));
          CustomGameEvent.dispatchEvent(EventName.UPDATE_TIME, newDisplayTime);
          if (newDisplayTime !== this.currentDisplayTime) {
            this.currentDisplayTime = newDisplayTime;
            this.updateTimeDisplay();
          }
          if (this.currentTime <= 0) {
            var _this$onTimerFinished;
            this.currentTime = 0;
            this.currentDisplayTime = 0;
            this.updateTimeDisplay();
            this.stopTimer();
            (_this$onTimerFinished = this.onTimerFinished) == null || _this$onTimerFinished.call(this);
            console.log('Timer finished.');
          }
        };
        _proto.updateTimeDisplay = function updateTimeDisplay() {
          if (!this.timeDigit1 || !this.timeDigit2) return;
          var colorRed = Color.fromHEX(new Color(), 'F85E43');
          var colorWhite = Color.WHITE;
          var strTime = this.currentDisplayTime.toString().padStart(2, '0');
          this.timeDigit1.string = strTime.charAt(0);
          this.timeDigit2.string = strTime.charAt(1);
          if (this.currentDisplayTime < 10) {
            this.timeDigit1.color = colorRed;
            this.timeDigit2.color = colorRed;
          } else {
            this.timeDigit1.color = colorWhite;
            this.timeDigit2.color = colorWhite;
          }
        };
        return Timer;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "timeDigit1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "timeDigit2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/TutorialController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './GameController.ts', './SoundController.ts', './AudioId.ts', './GameConfig.ts', './TextController.ts', './DataModel.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, Node, Label, Component, v3, GameController, SoundController, AudioId, Config, TextController, DataModel;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Node = module.Node;
      Label = module.Label;
      Component = module.Component;
      v3 = module.v3;
    }, function (module) {
      GameController = module.GameController;
    }, function (module) {
      SoundController = module.SoundController;
    }, function (module) {
      AudioId = module.AudioId;
    }, function (module) {
      Config = module.Config;
    }, function (module) {
      TextController = module.default;
    }, function (module) {
      DataModel = module.DataModel;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14;
      cclegacy._RF.push({}, "79666WahCpPIbha6EMOIs3h", "TutorialController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var PopupBackground = /*#__PURE__*/function (PopupBackground) {
        PopupBackground[PopupBackground["Down"] = 0] = "Down";
        PopupBackground[PopupBackground["Up"] = 1] = "Up";
        PopupBackground[PopupBackground["Left"] = 2] = "Left";
        PopupBackground[PopupBackground["Right"] = 3] = "Right";
        return PopupBackground;
      }(PopupBackground || {});
      var TutorialController = exports('TutorialController', (_dec = ccclass('TutorialController'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Label), _dec5 = property(Node), _dec6 = property(Label), _dec7 = property(Node), _dec8 = property(Node), _dec9 = property(Node), _dec10 = property(Node), _dec11 = property(Node), _dec12 = property(Node), _dec13 = property(Node), _dec14 = property(Node), _dec15 = property(GameController), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(TutorialController, _Component);
        function TutorialController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "container", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "hintPopupNode", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "hintPopupLabel", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "counterNode", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "counterLabel", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "gestureNode", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "popupBgDown", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "popupBgUp", _descriptor8, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "popupBgLeft", _descriptor9, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "popupBgRight", _descriptor10, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "scoreNode", _descriptor11, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "timerNode", _descriptor12, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "livesNode", _descriptor13, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "gameController", _descriptor14, _assertThisInitialized(_this));
          _this.resolveCallback = null;
          _this.startCounter = 3;
          _this.showTutorial = Config.DEFAULT_SHOW_TUTORIAL;
          _this._hintPopupDefaultY = 0;
          return _this;
        }
        var _proto = TutorialController.prototype;
        _proto.start = function start() {
          this.reset();
          var pos = this.hintPopupNode.getPosition();
          this._hintPopupDefaultY = pos.y;
          this.showTutorial = DataModel.data.showTutorial;
          if (this.showTutorial) {
            this.startTutorial();
          } else {
            this.startCountDown();
          }
        };
        _proto.reset = function reset() {
          var nodesToReset = [this.container, this.hintPopupNode, this.counterNode, this.gestureNode, this.popupBgDown, this.popupBgUp, this.popupBgLeft, this.popupBgRight, this.scoreNode, this.timerNode, this.livesNode];
          nodesToReset.forEach(function (node) {
            return node.active = false;
          });
        };
        _proto.startTutorial = /*#__PURE__*/function () {
          var _startTutorial = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  _context.prev = 0;
                  _context.next = 3;
                  return this.showHint(this.gestureNode, "TUT_1", PopupBackground.Down, v3(0, 121, 0));
                case 3:
                  _context.next = 5;
                  return this.showHint(this.timerNode, "TUT_2", PopupBackground.Up, v3(0, this._hintPopupDefaultY, 0));
                case 5:
                  _context.next = 7;
                  return this.showHint(this.livesNode, "TUT_3", PopupBackground.Right, v3(60, this._hintPopupDefaultY, 0));
                case 7:
                  _context.next = 9;
                  return this.showHint(this.scoreNode, "TUT_4", PopupBackground.Left, v3(-65, this._hintPopupDefaultY, 0));
                case 9:
                  this.startCountDown();
                  _context.next = 15;
                  break;
                case 12:
                  _context.prev = 12;
                  _context.t0 = _context["catch"](0);
                  console.error('Error in tutorial:', _context.t0);
                case 15:
                case "end":
                  return _context.stop();
              }
            }, _callee, this, [[0, 12]]);
          }));
          function startTutorial() {
            return _startTutorial.apply(this, arguments);
          }
          return startTutorial;
        }();
        _proto.showHint = function showHint(targetNode, message, popupBg, position) {
          var _this2 = this;
          return new Promise(function (resolve) {
            _this2.reset();
            targetNode.active = true;
            var str = TextController.getRawText(message);
            if (message == "TUT_2") {
              str = str.replace("{0}", String(DataModel.data.time));
            }
            _this2.showHintPopup(str);
            _this2.setPopupBackground(popupBg);
            _this2.hintPopupNode.setPosition(position);
            _this2.resolveCallback = resolve;
          });
        };
        _proto.showHintPopup = function showHintPopup(msg) {
          this.container.active = true;
          this.hintPopupNode.active = true;
          this.hintPopupLabel.string = msg;
        };
        _proto.setPopupBackground = function setPopupBackground(popupBg) {
          this.popupBgDown.active = popupBg === PopupBackground.Down;
          this.popupBgUp.active = popupBg === PopupBackground.Up;
          this.popupBgLeft.active = popupBg === PopupBackground.Left;
          this.popupBgRight.active = popupBg === PopupBackground.Right;
        };
        _proto.startCountDown = /*#__PURE__*/function () {
          var _startCountDown = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  if (!DataModel.data.firstTimeToday) {
                    _context2.next = 3;
                    break;
                  }
                  _context2.next = 3;
                  return this.showHint(this.scoreNode, "TUT_5", PopupBackground.Down, v3(0, 121, 0));
                case 3:
                  this.reset();
                  this.counterNode.active = true;
                  this.startCounter = 3;
                  this.counterLabel.string = this.startCounter.toString();
                  if (Config.SKIP_COUNTDOWN) {
                    this.startGame();
                  } else {
                    this.schedule(this.scheduleCountDown.bind(this), 1, 3, 0);
                  }
                case 8:
                case "end":
                  return _context2.stop();
              }
            }, _callee2, this);
          }));
          function startCountDown() {
            return _startCountDown.apply(this, arguments);
          }
          return startCountDown;
        }();
        _proto.scheduleCountDown = function scheduleCountDown() {
          this.startCounter--;
          if (this.startCounter <= 0) {
            this.unschedule(this.scheduleCountDown);
            this.startGame();
          } else {
            this.counterLabel.string = this.startCounter.toString();
          }
        };
        _proto.startGame = function startGame() {
          this.node.active = false;
          this.gameController.startGame();
          SoundController.playEffect(AudioId.metal_whistle);
        };
        _proto.onScreenTap = function onScreenTap() {
          if (this.resolveCallback) {
            this.resolveCallback();
            this.resolveCallback = null;
          }
        };
        return TutorialController;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "container", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "hintPopupNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "hintPopupLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "counterNode", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "counterLabel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "gestureNode", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "popupBgDown", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "popupBgUp", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "popupBgLeft", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "popupBgRight", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "scoreNode", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "timerNode", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "livesNode", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "gameController", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/UtilsStageLoading.ts", ['cc'], function (exports) {
  var cclegacy, _decorator, resources, error, assetManager;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      resources = module.resources;
      error = module.error;
      assetManager = module.assetManager;
    }],
    execute: function () {
      var _class;
      cclegacy._RF.push({}, "06086xD1I5LP4Fkyh+DHIXD", "UtilsStageLoading", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var UtilsStageLoading = exports('default', ccclass(_class = /*#__PURE__*/function () {
        function UtilsStageLoading() {}
        UtilsStageLoading.loadRes = function loadRes(url, type, cb) {
          // log("UtilsStageLoading loadRes: " + url);
          if (type) {
            resources.load(url, type, function (err, res) {
              if (err) {
                error(err.message || err);
                if (cb) {
                  cb(err, res);
                }
                return;
              }
              if (cb) {
                cb(err, res);
              }
            });
          } else {
            assetManager.loadRemote(url, function (err, res) {
              if (err) {
                error(err.message || err);
                if (cb) {
                  cb(err, res);
                }
                return;
              }
              if (cb) {
                cb(err, res);
              }
            });
          }
        };
        UtilsStageLoading.preLoadRes = function preLoadRes(url, type, cb) {
          resources.preload(url, type, function (err, res) {
            if (err) {
              error(err.message || err);
              if (cb) {
                cb(err, res);
              }
              return;
            }
            if (cb) {
              cb(err, res);
            }
          });
        };
        return UtilsStageLoading;
      }()) || _class);
      cclegacy._RF.pop();
    }
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});