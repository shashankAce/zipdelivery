System.register([], (function (exports) {
	'use strict';
	return {
		execute: (function () {

			exports("default", physx_release_asm);

			function physx_release_asm () {}

		})
	};
}));
