System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/physx.release.wasm-BKmf6XT6.wasm")}}}));
