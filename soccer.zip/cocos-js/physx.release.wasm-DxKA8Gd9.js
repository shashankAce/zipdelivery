System.register([], (function (exports, module) {
	'use strict';
	return {
		execute: (function () {

			var physx_release_wasm = exports("default", 'assets/physx.release.wasm-BKmf6XT6.wasm'); /* asset-hash:29c69d0f */

		})
	};
}));
