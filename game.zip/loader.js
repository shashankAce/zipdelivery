export default class Loader {
  constructor(options = {}) {
    this.TIMEOUT_SEC = options.timeout || 40;
    this.finished = 0;
    this.progressOver = false;
    this.networkTimer = null;

    this.bar = document.getElementById("progress-bar");
    this.barCont = document.getElementById("bar_cont");
    this.modal = document.getElementById("error-modal");
    this.btnExit = document.getElementById("btn_left");
    this.btnRetry = document.getElementById("btn_right");
    this.splashBg = document.getElementById("fullscreen-bg");
    this.sponsor = document.getElementById("sponsor");

    this.translations = {
      en: {
        header: "Unable to load game!",
        msg_content: "Please check your internet connection or disable VPN/lockdown mode if on.",
        retry: "RETRY",
        exit: "EXIT",
        sponsor: "Sponsored By"
      },
      ar: {
        header: "غير قادر على تحميل اللعبة!",
        msg_content: "يرجى التحقق من اتصالك بالإنترنت أو تعطيل VPN/وضع الحظر إذا كان قيد التشغيل.",
        retry: "إعادة المحاولة",
        exit: "خروج",
        sponsor: "برعاية"
      }
    };

    this.lang = window.noonApi?.getLanguage?.() || "en";
  }

  init() {
    this._injectTranslations();
    this._attachListeners();
    this.startTime = Date.now();

    this.splashBg.addEventListener("load", () => {
      console.log("Splash image loaded");
      this.updateBar();
    });

    if (this.splashBg.complete) {
      console.log("Splash image was already cached");
      this.updateBar();
    }

    this.networkTimer = setTimeout(() => {
      this.showNetworkError();
    }, this.TIMEOUT_SEC * 1000);
  }

  _injectTranslations() {
    const t = this.translations[this.lang] || this.translations.en;
    document.getElementById("msg_head").innerText = t.header;
    document.getElementById("msg_content").innerText = t.msg_content;
    this.sponsor.innerText = t.sponsor;

    this.btnRetry.innerText = t.retry;
    this.btnExit.innerText = t.exit;

    if (this.lang === "ar") {
      document.querySelector(".modal-box").style.direction = "rtl";
    }
  }

  _attachListeners() {
    this.btnExit.addEventListener("click", () => {
      window.noonApi?.closeGame();
      window.noonApi?.trackNATEvent?.("loader_error_action ", { action: "exit", pn: "loader" });
    });

    this.btnRetry.addEventListener("click", () => {
      location.reload();
      window.noonApi?.trackNATEvent?.("loader_error_action ", { action: "retry", pn: "loader" });
    });

    this.splashBg.addEventListener("click", () => {
      // blocking events below
    });
  }

  updateBar() {
    if (this.progressOver) return;

    if (navigator.onLine) {
      this.finished += this._randomBetween(1, 5);
      const percent = Math.min(100, Math.floor(this.finished));
      if (this.bar) this.bar.style.width = percent + "%";

      if (percent >= 90) {
        this.progressOver = true;
      }
    }

    setTimeout(() => this.updateBar(), this._randomBetween(200, 300));
  }

  showNetworkError() {
    this.modal.style.visibility = "visible";
    document.getElementById("pre_splash").style.display = "block";
    this.barCont.style.display = "none";

    window.noonApi?.trackNATEvent?.('error', {
      error_code: `Gameload timeout`,
      pn: 'loader'
    });
  }

  clearNetworkTimeout() {
    clearTimeout(this.networkTimer);
  }

  onGameLoaded() {
    this.progressOver = true;

    this.bar.style.width = 100 + "%";
    this.modal.style.visibility = "hidden";

    const preSplash = document.getElementById("pre_splash");
    setTimeout(() => {
      if (preSplash) preSplash.style.display = "none";
    }, 200);

    const timeDiff = (Date.now() - this.startTime) / 1000;
    window.noonApi?.trackNATEvent?.("loader", { time_diff: timeDiff, pn: 'Homescreen' });
  }

  _randomBetween(min, max) {
    return Math.random() * (max - min) + min;
  }
}
